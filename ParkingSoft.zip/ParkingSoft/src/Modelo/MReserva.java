package Modelo;

import java.util.Date;

public class MReserva {
    
    private int id;
    private java.util.Date fecha_ingreso, fecha_salida;
    private Double subtotal, iva, total, costo_hora;
    private MVehiculo mVehiculo;
    private MTrabajador mTrabajador;

    public MReserva() {
        this.mVehiculo = new MVehiculo();
        this.mTrabajador = new MTrabajador();
    }

    public MReserva(int id, Date fecha_ingreso, Date fecha_salida, Double subtotal, Double iva, Double total, MVehiculo mVehiculo, MTrabajador mTrabajador, double costo_hora) {
        this.id = id;
        this.fecha_ingreso = fecha_ingreso;
        this.fecha_salida = fecha_salida;
        this.costo_hora = costo_hora;
        this.subtotal = subtotal;
        this.iva = iva;
        this.total = total;
        this.mVehiculo = mVehiculo;
        this.mTrabajador = mTrabajador;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.util.Date getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(java.util.Date fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    public java.util.Date getFecha_salida() {
        return fecha_salida;
    }

    public void setFecha_salida(java.util.Date fecha_salida) {
        this.fecha_salida = fecha_salida;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.subtotal = subtotal;
    }

    public Double getIva() {
        return iva;
    }

    public void setIva(Double iva) {
        this.iva = iva;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public MVehiculo getmVehiculo() {
        return mVehiculo;
    }

    public void setmVehiculo(MVehiculo mVehiculo) {
        this.mVehiculo = mVehiculo;
    }

    public MTrabajador getmTrabajador() {
        return mTrabajador;
    }

    public void setmTrabajador(MTrabajador mTrabajador) {
        this.mTrabajador = mTrabajador;
    }

    public Double getCosto_hora() {
        return costo_hora;
    }

    public void setCosto_hora(Double costo_hora) {
        this.costo_hora = costo_hora;
    }
    
}
