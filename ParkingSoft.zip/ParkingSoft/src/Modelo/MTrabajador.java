package Modelo;

public class MTrabajador extends MPersona {
    
    private int id, id_persona, id_trabajador_rol, id_estatus, id_trabajador_contrato;
    private double sueldo;
    private String user, password, salt;

    public MTrabajador() {
        
    }

    public MTrabajador(int id, int id_persona, int id_trabajador_rol, int id_estatus, int id_trabajador_contrato, int id_documento_tipo, String nombres, String apellidos, String nu_documento, String documento_tipo, String direccion, String telefono, String celular, String email, double sueldo, String user, String password, String salt) {
        this.id = id;
        this.id_persona = id_persona;
        this.id_trabajador_rol = id_trabajador_rol;
        this.id_estatus = id_estatus;
        this.id_trabajador_contrato = id_trabajador_contrato;
        super.setId_documento_tipo(id_documento_tipo);
        super.setNombres(nombres);
        super.setApellidos(apellidos);
        super.setNu_documento(nu_documento);
        super.setDocumento_tipo(documento_tipo);
        super.setDireccion(direccion);
        super.setTelefono(telefono);
        super.setCelular(celular);
        super.setEmail(email);
        this.sueldo = sueldo;
        this.user = user;
        this.password = password;
        this.salt = salt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_persona() {
        return id_persona;
    }

    public void setId_persona(int id_persona) {
        this.id_persona = id_persona;
    }

    public int getId_trabajador_rol() {
        return id_trabajador_rol;
    }

    public void setId_trabajador_rol(int id_trabajador_rol) {
        this.id_trabajador_rol = id_trabajador_rol;
    }

    public int getId_estatus() {
        return id_estatus;
    }

    public void setId_estatus(int id_estatus) {
        this.id_estatus = id_estatus;
    }

    public int getId_trabajador_contrato() {
        return id_trabajador_contrato;
    }

    public void setId_trabajador_contrato(int id_trabajador_contrato) {
        this.id_trabajador_contrato = id_trabajador_contrato;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }
    
}
