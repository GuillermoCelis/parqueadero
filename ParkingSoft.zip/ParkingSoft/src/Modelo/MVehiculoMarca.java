package Modelo;

public class MVehiculoMarca {
    
    private int id;
    private String marca;

    public MVehiculoMarca() {
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
}
