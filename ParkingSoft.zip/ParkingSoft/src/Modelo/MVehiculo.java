package Modelo;

public class MVehiculo {
    
    private int id, id_estatus, ano;
    private String placa, color;
    private MVehiculoTipo mVehiculoTipo;
    private MVehiculoModelo mVehiculoModelo;
    private MPersona mPropietario;

    public MVehiculo() {
        this.mVehiculoTipo = new MVehiculoTipo();
        this.mVehiculoModelo = new MVehiculoModelo();
        this.mPropietario = new MPersona();
    }

    public MVehiculo(int id, int id_estatus, int ano, String placa, String color, MVehiculoTipo mVehiculoTipo, MVehiculoModelo mVehiculoModelo, MPersona mPropietario) {
        this.id = id;
        this.id_estatus = id_estatus;
        this.ano = ano;
        this.placa = placa;
        this.color = color;
        this.mVehiculoTipo = mVehiculoTipo;
        this.mVehiculoModelo = mVehiculoModelo;
        this.mPropietario = mPropietario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_estatus() {
        return id_estatus;
    }

    public void setId_estatus(int id_estatus) {
        this.id_estatus = id_estatus;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public MVehiculoModelo getmVehiculoModelo() {
        return mVehiculoModelo;
    }

    public void setmVehiculoModelo(MVehiculoModelo mVehiculoModelo) {
        this.mVehiculoModelo = mVehiculoModelo;
    }

    public MPersona getmPropietario() {
        return mPropietario;
    }

    public void setmPropietario(MPersona mPropietario) {
        this.mPropietario = mPropietario;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public MVehiculoTipo getmVehiculoTipo() {
        return mVehiculoTipo;
    }

    public void setmVehiculoTipo(MVehiculoTipo mVehiculoTipo) {
        this.mVehiculoTipo = mVehiculoTipo;
    }
    
}
