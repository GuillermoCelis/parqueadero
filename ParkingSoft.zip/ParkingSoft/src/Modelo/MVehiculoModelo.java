package Modelo;

public class MVehiculoModelo {
    
    private int id;
    private String modelo;
    private MVehiculoMarca mVehiculoMarca;

    public MVehiculoModelo() {
        this.mVehiculoMarca = new MVehiculoMarca();
    }

    public MVehiculoModelo(int id, String modelo, MVehiculoMarca mVehiculoMarca) {
        this.id = id;
        this.modelo = modelo;
        this.mVehiculoMarca = mVehiculoMarca;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public MVehiculoMarca getmVehiculoMarca() {
        return mVehiculoMarca;
    }

    public void setmVehiculoMarca(MVehiculoMarca mVehiculoMarca) {
        this.mVehiculoMarca = mVehiculoMarca;
    }
    
}
