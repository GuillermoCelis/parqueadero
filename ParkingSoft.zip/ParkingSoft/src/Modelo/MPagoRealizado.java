package Modelo;

import java.util.Date;

public class MPagoRealizado {
    
    private int id, id_reserva;
    private String nu_referencia;
    private double nu_monto, total_a_pagar, total_pagado, cambio;
    private Date f_pago;
    private MPagoTipo mPagoTipo;

    public MPagoRealizado() {
        this.mPagoTipo = new MPagoTipo();
    }

    public String getNu_referencia() {
        return nu_referencia;
    }

    public void setNu_referencia(String nu_referencia) {
        this.nu_referencia = nu_referencia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public double getNu_monto() {
        return nu_monto;
    }

    public void setNu_monto(double nu_monto) {
        this.nu_monto = nu_monto;
    }

    public Date getF_pago() {
        return f_pago;
    }

    public void setF_pago(Date f_pago) {
        this.f_pago = f_pago;
    }

    public MPagoTipo getmPagoTipo() {
        return mPagoTipo;
    }

    public void setmPagoTipo(MPagoTipo mPagoTipo) {
        this.mPagoTipo = mPagoTipo;
    }

    public double getTotal_a_pagar() {
        return total_a_pagar;
    }

    public void setTotal_a_pagar(double total_a_pagar) {
        this.total_a_pagar = total_a_pagar;
    }

    public double getTotal_pagado() {
        return total_pagado;
    }

    public void setTotal_pagado(double total_pagado) {
        this.total_pagado = total_pagado;
    }

    public double getCambio() {
        return cambio;
    }

    public void setCambio(double cambio) {
        this.cambio = cambio;
    }
    
    
    
}
