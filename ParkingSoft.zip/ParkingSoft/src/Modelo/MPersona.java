package Modelo;

public class MPersona {
    private int id, id_documento_tipo;
    private String nombres, apellidos, nu_documento, documento_tipo, direccion, telefono, celular, email;

    public MPersona() {
        
    }
    
    public MPersona(int id, int id_documento_tipo, String nombres, String apellidos, String nu_documento, String direccion, String telefono, String celular, String email) {
        this.id = id;
        this.id_documento_tipo = id_documento_tipo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.nu_documento = nu_documento;
        this.direccion = direccion;
        this.telefono = telefono;
        this.celular = celular;
        this.email = email;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_documento_tipo() {
        return id_documento_tipo;
    }

    public void setId_documento_tipo(int id_documento_tipo) {
        this.id_documento_tipo = id_documento_tipo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNu_documento() {
        return nu_documento;
    }

    public void setNu_documento(String nu_documento) {
        this.nu_documento = nu_documento;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDocumento_tipo() {
        return documento_tipo;
    }

    public void setDocumento_tipo(String documento_tipo) {
        this.documento_tipo = documento_tipo;
    }
    
}
