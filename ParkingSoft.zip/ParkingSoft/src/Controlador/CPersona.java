package Controlador;

import Modelo.MPersona;
import Modelo.MTrabajador;
import Vista.Panel.VPTrabajadores;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jhon
 */
public class CPersona {

    private Conexion mysql = new Conexion();
    private Connection cn = mysql.conectar();
    private String sSQL = "";
    public Vector<MPersona> registros;
    public Integer totalRegistros;
    
    public static enum TIPO_BUSQUEDA {
        General, 
        Usuario, 
        Nombres_Apellidos, 
        N_Documento
    }
    
    public boolean existePersona(String nu_documento) {
        sSQL = "SELECT id FROM persona WHERE nu_documento = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, nu_documento);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    public MPersona obtenerPersona(String nu_documento) {
        MPersona mPersona = new MPersona();
        try {
            sSQL = "SELECT * FROM persona WHERE nu_documento = ?; ";
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, nu_documento);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                mPersona.setId(rs.getInt(1));
                mPersona.setId_documento_tipo(rs.getInt(2));
                mPersona.setNombres(rs.getString(3));
                mPersona.setApellidos(rs.getString(4));
                mPersona.setNu_documento(rs.getString(5));
                mPersona.setDireccion(rs.getString(6));
                mPersona.setTelefono(rs.getString(7));
                mPersona.setCelular(rs.getString(8));
                mPersona.setEmail(rs.getString(9));
                return mPersona;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return null;
    }

    public void mostrar(TIPO_BUSQUEDA tipoBusqueda, String buscar, DefaultTableModel defaultTableModel) {
        registros = new Vector();
        while(defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }
        if (tipoBusqueda.equals(TIPO_BUSQUEDA.General)) {
            sSQL = "SELECT * FROM persona WHERE id NOT IN (SELECT id_persona FROM trabajador) AND (nombres LIKE ? OR apellidos LIKE ? OR nu_documento LIKE ?); ";
        }
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            if (tipoBusqueda.equals(TIPO_BUSQUEDA.General)) {
                ps.setString(1, "%" + buscar + "%");
                ps.setString(2, "%" + buscar + "%");
                ps.setString(3, "%" + buscar + "%");
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MPersona mPersona = new MPersona();
                for (int column = 1; column <= rs.getMetaData().getColumnCount(); column++) {
                    mPersona.setId(rs.getInt("id"));
                    mPersona.setId_documento_tipo(rs.getInt("id_documento_tipo"));
                    mPersona.setNombres(rs.getString("nombres"));
                    mPersona.setApellidos(rs.getString("apellidos"));
                    mPersona.setNu_documento(rs.getString("nu_documento"));
                    mPersona.setDireccion(rs.getString("direccion"));
                    mPersona.setTelefono(rs.getString("telefono"));
                    mPersona.setCelular(rs.getString("celular"));
                    mPersona.setEmail(rs.getString("email"));
                }
                registros.add(mPersona);
                if (tipoBusqueda.equals(TIPO_BUSQUEDA.General)) {
                    defaultTableModel.addRow(new Object[] {registros.size(), (mPersona.getNombres() + " " + mPersona.getApellidos()), mPersona.getNu_documento()});
                }
            }

            //return modelo;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }
    
    public void selectRegistro(VPTrabajadores vpTrabajadores) {
        
    }

    public boolean insertar(MTrabajador dts) {
        /*
        sSQL = "insert into persona (nombre,apellidop,apellidom,tipo_id,num_id,direccion,telefono,celular,email)"
                + " values (?,?,?,?,?,?,?,?,?)";
        sSQL2 = "insert into trabajador (idpersona,sueldo,acceso,login,password,estado)"
                + " values ((select idpersona from persona order by idpersona desc limit 1),?,?,?,?,?)";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getApellidop());
            pst.setString(3, dts.getApellidom());
            pst.setString(4, dts.getTipoID());
            pst.setString(5, dts.getNumeroID());
            pst.setString(6, dts.getDireccion());
            pst.setInt(7, dts.getTelefono());
            pst.setString(8, dts.getCelular());
            pst.setString(9, dts.getEmail());

            pst2.setDouble(1, dts.getSueldo());
            pst2.setString(2, dts.getAcceso());
            pst2.setString(3, dts.getLogin());
            pst2.setString(4, dts.getPassword());
            pst2.setString(5, dts.getEstado());

            int n = pst.executeUpdate();

            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) 
                    return true;
                else 
                    return false;
                
            }else
                return false;

        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
        */
        return false;
    }

    public boolean editar(MTrabajador dts) {
        /*
        sSQL = "update persona set nombre=?,apellidop=?,apellidom=?,tipo_id=?,num_id=?,direccion=?,telefono=?,celular=?,email=?"
                + " where idpersona=?";
        sSQL2 = "update trabajador set sueldo=?,acceso=?,login=?,password=?,estado=?"
                + " where idpersona=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getApellidop());
            pst.setString(3, dts.getApellidom());
            pst.setString(4, dts.getTipoID());
            pst.setString(5, dts.getNumeroID());
            pst.setString(6, dts.getDireccion());
            pst.setInt(7, dts.getTelefono());
            pst.setString(8, dts.getCelular());
            pst.setString(9, dts.getEmail());
            pst.setInt(10, dts.getIdPersona());

            pst2.setDouble(1, dts.getSueldo());
            pst2.setString(2, dts.getAcceso());
            pst2.setString(3, dts.getLogin());
            pst2.setString(4, dts.getPassword());
            pst2.setString(5, dts.getEstado());
            pst2.setInt(6, dts.getIdPersona());

            int n = pst.executeUpdate();

            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) 
                    return true;
                else 
                    return false;
                
            }else
                return false;

        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
        */
        return false;
    }

    public boolean eliminar(MTrabajador dts) {
        /*
        sSQL = "delete from trabajador where idpersona=?";
        sSQL2 = "delete from persona where idpersona=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            
            
            pst.setInt(1, dts.getIdPersona());

            pst.setInt(1, dts.getIdPersona());

            int n = pst.executeUpdate();

            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) 
                    return true;
                else 
                    return false;
                
            }else
                return false;

        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
        */
        return false;
    }
    public DefaultTableModel login(String login, String pass) {
        DefaultTableModel modelo;
        String[] titulos = {"ID", "Nombre", "1er Apellido", "2do Apellido", "Acceso", "Login", "Clave", "Estado"};
        String[] registro = new String[8];
        totalRegistros = 0;
        modelo = new DefaultTableModel(null, titulos);
        sSQL = "select p.idpersona,p.nombre,p.apellidop,p.apellidom,"
                + "t.acceso,t.login,t.password,t.estado from persona p inner join trabajador t "
                + "on p.idpersona=t.idpersona where t.login='" + login + "' and t.password='" +pass+"'and"
                + " t.estado='Habilitado'";

        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);

            while (rs.next()) {
                registro[0] = rs.getString("idpersona");
                registro[1] = rs.getString("nombre");
                registro[2] = rs.getString("apellidop");
                registro[3] = rs.getString("apellidom");
                registro[4] = rs.getString("acceso");
                registro[5] = rs.getString("login");
                registro[6] = rs.getString("password");
                registro[7] = rs.getString("estado");

                totalRegistros++;
                modelo.addRow(registro);
            }

            return modelo;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }

}
