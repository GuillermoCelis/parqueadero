package Controlador;

import Modelo.MPersona;
import Modelo.MTrabajador;
import Modelo.MVehiculo;
import Vista.Panel.VPVehiculos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CVehiculo {

    private Conexion mysql = new Conexion();
    private Connection cn = mysql.conectar();
    public Vector<MVehiculo> registros;
    public Integer totalRegistros;

    // Vehículo tipo
    private Vector vehiculoTipo[] = new Vector[2];
    // Vehículo marca
    private Vector vehiculoMarca[] = new Vector[2];
    // Vehículo modelo
    private Vector vehiculoModelo[] = new Vector[2];
    // Estatus
    private Vector estatus[] = new Vector[2];
    // Tipo de documento
    private Vector documentoTipo[] = new Vector[2];
    // Datos de clientes
    private Vector<MPersona> clientes = new Vector();

    public CVehiculo() {
        init();
    }

    private void init() {
        cargarDataGeneral(null);
    }

    public void cargarDataGeneral(VPVehiculos formulario) {
        cargarData("Vehículo tipo", 0);
        cargarData("Vehículo marca", 0);
        cargarData("Estatus", 0);
        cargarData("Documento tipo", 0);
        cargarData("Cliente", 0);
        if (formulario != null) {
            montarData(formulario.comboBoxVehiculoTipo, "Vehículo tipo");
            montarData(formulario.comboBoxMarca, "Vehículo marca");
            montarData(formulario.comboBoxEstatus, "Estatus");
            montarData(formulario.comboBoxDocumentoTipo, "Documento tipo");
        }
    }

    public void cargarData(String tipoData, int id) {
        Vector vectorData[] = null;
        String sSQL = "";
        if (tipoData.equals("Vehículo tipo")) {
            vectorData = vehiculoTipo;
            sSQL = "SELECT * FROM vehiculo_tipo ORDER BY id ASC; ";
        } else if (tipoData.equals("Vehículo marca")) {
            vectorData = vehiculoMarca;
            sSQL = "SELECT * FROM vehiculo_marca ORDER BY marca ASC; ";
        } else if (tipoData.equals("Vehículo modelo")) {
            vectorData = vehiculoModelo;
            sSQL = "SELECT vmodelo.id, vmodelo.modelo FROM vehiculo_modelo vmodelo INNER JOIN vehiculo_marca vmarca ON vmodelo.id_vehiculo_marca = vmarca.id WHERE vmarca.id = ? ORDER BY vmarca.marca ASC; ";
        } else if (tipoData.equals("Estatus")) {
            vectorData = estatus;
            sSQL = "SELECT * FROM estatus ORDER BY id ASC; ";
        } else if (tipoData.equals("Documento tipo")) {
            vectorData = documentoTipo;
            sSQL = "SELECT * FROM documento_tipo ORDER BY id ASC; ";
        } else if (tipoData.equals("Cliente")) {
            sSQL = "SELECT * FROM persona ORDER BY id ASC; ";
        }
        if (vectorData != null) {
            for (int i = 0; i < vectorData.length; i++) {
                vectorData[i] = new Vector();
            }
        }
        try {
            ResultSet rs = null;
            if (id > 0) {
                PreparedStatement ps = cn.prepareStatement(sSQL);
                ps.setInt(1, id);
                rs = ps.executeQuery();
            } else {
                rs = cn.createStatement().executeQuery(sSQL);
            }
            while (rs.next()) {
                if (tipoData.equals("Cliente")) {
                    MPersona mPersona = new MPersona();
                    mPersona.setId(rs.getInt("id"));
                    mPersona.setNombres(rs.getString("nombres"));
                    mPersona.setApellidos(rs.getString("apellidos"));
                    mPersona.setId_documento_tipo(rs.getInt("id_documento_tipo"));
                    mPersona.setNu_documento(rs.getString("nu_documento"));
                    clientes.add(mPersona);
                } else {
                    vectorData[0].add(rs.getInt(1));
                    vectorData[1].add(rs.getString(2));
                }
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public MPersona obtenerCliente(String nu_documento) {
        MPersona mPersona = null;
        String sSQL = "";
        sSQL = "SELECT id, nu_documento, nombres, apellidos FROM persona WHERE nu_documento = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, nu_documento);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                mPersona = new MPersona();
                mPersona.setId(rs.getInt("id"));
                mPersona.setNombres(rs.getString("nombres"));
                mPersona.setApellidos(rs.getString("apellidos"));
                return mPersona;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return null;
    }

    public void montarData(JComboBox combobox, String tipoData) {
        combobox.removeAllItems();
        combobox.addItem("Seleccione");
        Vector[] vectorData = null;
        if (tipoData.equals("Vehículo tipo")) {
            vectorData = vehiculoTipo;
        } else if (tipoData.equals("Vehículo marca")) {
            vectorData = vehiculoMarca;
        } else if (tipoData.equals("Vehículo modelo")) {
            vectorData = vehiculoModelo;
        } else if (tipoData.equals("Estatus")) {
            vectorData = estatus;
        } else if (tipoData.equals("Documento tipo")) {
            vectorData = documentoTipo;
        }
        for (int i = 0; i < vectorData[1].size(); i++) {
            combobox.addItem(vectorData[1].get(i));
        }
    }

    public boolean existeVehiculo(String placa) {
        String sSQL = "SELECT id FROM vehiculo WHERE placa = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public MVehiculo obtenerVehiculo(String placa) {
        for (MVehiculo vehiculo : registros) {
            if (vehiculo.getPlaca().equals(placa)) {
                return vehiculo;
            }
        }
        return null;
    }

    public MVehiculo obtenerVehiculo(int index) {
        return registros.get(index);
    }

    public int obtenerMarcaId(int indexComboBox) {
        return Integer.valueOf(vehiculoMarca[0].get(indexComboBox - 1).toString());
    }

    public void mostrar(String buscar, DefaultTableModel defaultTableModel) {
        registros = new Vector();
        while (defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }
        String sSQL = "SELECT v.id AS id_vehiculo, v.id_vehiculo_modelo, v.id_propietario, v.id_estatus, v.placa, v.color, vmarca.id AS id_vehiculo_marca, vmarca.marca, vtipo.id AS id_vehiculo_tipo, vtipo.tipo, vmodelo.id AS id_vehiculo_modelo, vmodelo.modelo, v.ano, p.nombres, p.apellidos, p.nu_documento, dt.tipo AS documento_tipo FROM vehiculo AS v INNER JOIN vehiculo_modelo vmodelo ON v.id_vehiculo_modelo = vmodelo.id INNER JOIN vehiculo_marca vmarca ON vmodelo.id_vehiculo_marca = vmarca.id INNER JOIN vehiculo_tipo vtipo ON v.id_vehiculo_tipo = vtipo.id INNER JOIN persona p ON v.id_propietario = p.id INNER JOIN documento_tipo dt ON p.id_documento_tipo = dt.id WHERE v.placa LIKE ? OR v.color LIKE ? OR vmarca.marca LIKE ? OR vmodelo.modelo LIKE ? OR p.nombres like ? OR p.apellidos LIKE ? OR p.nu_documento LIKE ? ORDER BY vmarca.marca ASC, vmodelo.modelo; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, "%" + buscar + "%");
            ps.setString(2, "%" + buscar + "%");
            ps.setString(3, "%" + buscar + "%");
            ps.setString(4, "%" + buscar + "%");
            ps.setString(5, "%" + buscar + "%");
            ps.setString(6, "%" + buscar + "%");
            ps.setString(7, "%" + buscar + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MVehiculo mVehiculo = new MVehiculo();
                // vehiculo
                mVehiculo.setId(rs.getInt("id_vehiculo"));
                mVehiculo.setId_estatus(rs.getInt("id_estatus"));
                mVehiculo.setPlaca(rs.getString("placa"));
                mVehiculo.setColor(rs.getString("color"));
                mVehiculo.setAno(rs.getInt("ano"));

                // vehiculo_modelo
                mVehiculo.getmVehiculoModelo().setId(rs.getInt("id_vehiculo_modelo"));
                mVehiculo.getmVehiculoModelo().setModelo(rs.getString("modelo"));

                // vehiculo_marca
                mVehiculo.getmVehiculoModelo().getmVehiculoMarca().setId(rs.getInt("id_vehiculo_marca"));
                mVehiculo.getmVehiculoModelo().getmVehiculoMarca().setMarca(rs.getString("marca"));

                // vehiculo_tipo
                mVehiculo.getmVehiculoTipo().setId(rs.getInt("id_vehiculo_tipo"));
                mVehiculo.getmVehiculoTipo().setTipo(rs.getString("tipo"));

                // persona
                mVehiculo.getmPropietario().setId(rs.getInt("id_propietario"));
                mVehiculo.getmPropietario().setNombres(rs.getString("nombres"));
                mVehiculo.getmPropietario().setApellidos(rs.getString("apellidos"));
                mVehiculo.getmPropietario().setNu_documento(rs.getString("nu_documento"));
                mVehiculo.getmPropietario().setDocumento_tipo(rs.getString("documento_tipo"));

                registros.add(mVehiculo);
                String placa = mVehiculo.getPlaca();
                String marca = mVehiculo.getmVehiculoModelo().getmVehiculoMarca().getMarca();
                String modelo = mVehiculo.getmVehiculoModelo().getModelo();
                String propietario = mVehiculo.getmPropietario().getNombres() + " " + mVehiculo.getmPropietario().getApellidos();
                defaultTableModel.addRow(new Object[]{registros.size(), placa, marca, modelo, propietario});
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public MVehiculo selectRegistro(VPVehiculos formulario, int index) {
        MVehiculo mVehiculo = registros.get(index);
        formulario.txtPlaca.setText(mVehiculo.getPlaca());
        formulario.comboBoxVehiculoTipo.setSelectedItem(mVehiculo.getmVehiculoTipo().getTipo());
        formulario.comboBoxMarca.setSelectedItem(mVehiculo.getmVehiculoModelo().getmVehiculoMarca().getMarca());
        formulario.comboBoxModelo.setSelectedItem(mVehiculo.getmVehiculoModelo().getModelo());
        formulario.txtAno.setText(String.valueOf(mVehiculo.getAno()));
        formulario.txtColor.setText(mVehiculo.getColor());
        formulario.comboBoxEstatus.setSelectedItem(estatus[1].get(estatus[0].indexOf(mVehiculo.getId_estatus())));

        formulario.comboBoxDocumentoTipo.setSelectedItem(mVehiculo.getmPropietario().getDocumento_tipo());
        formulario.txtNDocumento.setText(mVehiculo.getmPropietario().getNu_documento());
        formulario.txtNombres.setText(mVehiculo.getmPropietario().getNombres());
        formulario.txtApellidos.setText(mVehiculo.getmPropietario().getApellidos());

        formulario.txtPlaca.setEnabled(false);
        formulario.comboBoxDocumentoTipo.setEnabled(false);
        formulario.txtNDocumento.setEnabled(false);

        return mVehiculo;
    }

    public void cargarDatosCliente(VPVehiculos formulario) {
        for (MPersona mPersona : clientes) {
            String documentoFormulario = formulario.txtNDocumento.getText();
            String documentoRegistro = mPersona.getNu_documento();
            int idDocumentoTipoFormulario = Integer.valueOf(documentoTipo[0].get(formulario.comboBoxDocumentoTipo.getSelectedIndex() - 1).toString());
            int idDocumentoTipoRegistro = mPersona.getId_documento_tipo();
            if (documentoFormulario.equals(documentoRegistro) && idDocumentoTipoFormulario == idDocumentoTipoRegistro) {
                formulario.comboBoxDocumentoTipo.setEnabled(false);
                formulario.txtNDocumento.setEnabled(false);
                formulario.txtNombres.setText(mPersona.getNombres());
                formulario.txtApellidos.setText(mPersona.getApellidos());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No hay registros con la información ingresada", "Aviso", JOptionPane.ERROR_MESSAGE);
    }

    public boolean operacion(MVehiculo mVehiculo, VPVehiculos formulario, boolean modificar) {
        try {
            String sSQL = "";
            PreparedStatement ps = null;
            Vector t_dato = new Vector();
            Vector dato = new Vector();
            // Tipo
            mVehiculo.getmVehiculoTipo().setId(Integer.valueOf(vehiculoTipo[0].get(formulario.comboBoxVehiculoTipo.getSelectedIndex() - 1).toString()));
            // Estatus
            mVehiculo.setId_estatus(Integer.valueOf(estatus[0].get(formulario.comboBoxEstatus.getSelectedIndex() - 1).toString()));
            // Marca
            if (formulario.comboBoxMarca.getSelectedIndex() == -1) {
                // Debo añadir el registro a la tabla vehiculo_marca
                sSQL = "INSERT INTO vehiculo_marca (marca) VALUES (?); ";
                ps = cn.prepareStatement(sSQL);
                ps.setString(1, formulario.comboBoxMarca.getSelectedItem().toString());
                ps.executeQuery();
            } else {
                // El registro ya existe
                mVehiculo.getmVehiculoModelo().getmVehiculoMarca().setId(Integer.valueOf(vehiculoMarca[0].get(formulario.comboBoxMarca.getSelectedIndex() - 1).toString()));
            }
            // Modelo
            if (formulario.comboBoxModelo.getSelectedIndex() == -1) {
                // Debo añadir el registro a la tabla vehiculo_modelo
                // Verificar si la marca es nueva o no
                if (formulario.comboBoxMarca.getSelectedIndex() == -1) {
                    // Es nuevo
                    sSQL = "INSERT INTO vehiculo_modelo (id_vehiculo_marca, modelo) VALUES ((SELECT MAX(id) FROM vehiculo_marca), ?); ";
                    ps = cn.prepareStatement(sSQL);
                    ps.setString(1, formulario.comboBoxModelo.getSelectedItem().toString());
                    ps.executeQuery();
                } else {
                    // Ya existe
                    sSQL = "INSERT INTO vehiculo_modelo (id_vehiculo_marca, modelo) VALUES (?, ?); ";
                    ps = cn.prepareStatement(sSQL);
                    ps.setInt(1, mVehiculo.getmVehiculoModelo().getmVehiculoMarca().getId());
                    ps.setString(2, formulario.comboBoxModelo.getSelectedItem().toString());
                    ps.executeQuery();
                }

                // Terminar de armar el query
                if (!modificar) {
                    sSQL = "INSERT INTO vehiculo (id_vehiculo_modelo, id_vehiculo_tipo, id_propietario, id_estatus, placa, color, ano) VALUES ((SELECT MAX(id) FROM vehiculo_modelo), ?, ?, ?, ?, ?, ?); ";
                    ps = cn.prepareStatement(sSQL);
                    ps.setInt(1, mVehiculo.getmVehiculoTipo().getId());
                    ps.setInt(2, obtenerCliente(mVehiculo.getmPropietario().getNu_documento()).getId());
                    ps.setInt(3, mVehiculo.getId_estatus());
                    ps.setString(4, formulario.txtPlaca.getText());
                    ps.setString(5, formulario.txtColor.getText());
                    ps.setInt(6, Integer.valueOf(formulario.txtAno.getText()));
                    ps.executeQuery();
                } else {
                    sSQL = "UPDATE vehiculo SET id_vehiculo_modelo = (SELECT MAX(id) FROM vehiculo_modelo), id_vehiculo_tipo = ?, id_estatus = ?, color = ?, ano = ? WHERE id = ?; ";
                    ps = cn.prepareStatement(sSQL);
                    ps.setInt(1, mVehiculo.getmVehiculoTipo().getId());
                    ps.setInt(2, mVehiculo.getId_estatus());
                    ps.setString(3, formulario.txtColor.getText());
                    ps.setInt(4, mVehiculo.getAno());
                    ps.setInt(5, mVehiculo.getId());
                    ps.executeQuery();
                }
            } else {
                System.out.println("FLA 6");
                // El registro ya existe
                mVehiculo.getmVehiculoModelo().setId(Integer.valueOf(vehiculoModelo[0].get(formulario.comboBoxModelo.getSelectedIndex() - 1).toString()));
                // Terminar de armar el query
                if (!modificar) {
                    sSQL += "INSERT INTO vehiculo (id_vehiculo_modelo, id_vehiculo_tipo, id_propietario, id_estatus, placa, color, ano) VALUES (?, ?, ?, ?, ?, ?, ?); ";
                    ps = cn.prepareStatement(sSQL);
                    ps.setInt(1, mVehiculo.getmVehiculoModelo().getId());
                    ps.setInt(2, mVehiculo.getmVehiculoTipo().getId());
                    ps.setInt(3, obtenerCliente(mVehiculo.getmPropietario().getNu_documento()).getId());
                    ps.setInt(4, mVehiculo.getId_estatus());
                    ps.setString(5, formulario.txtPlaca.getText());
                    ps.setString(6, formulario.txtColor.getText());
                    ps.setInt(7, mVehiculo.getAno());
                    ps.executeQuery();
                } else {
                    sSQL = "UPDATE vehiculo SET id_vehiculo_modelo = ?, id_vehiculo_tipo = ?, id_estatus = ?, color = ?, ano = ? WHERE id = ?; ";
                    ps = cn.prepareStatement(sSQL);
                    ps.setInt(1, mVehiculo.getmVehiculoModelo().getId());
                    ps.setInt(2, mVehiculo.getmVehiculoTipo().getId());
                    ps.setInt(3, mVehiculo.getId_estatus());
                    ps.setString(4, formulario.txtColor.getText());
                    ps.setInt(5, mVehiculo.getAno());
                    ps.setInt(6, mVehiculo.getId());
                    ps.executeQuery();
                }
            }
            return true;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean eliminar(MVehiculo mVehiculo) {
        String sSQL = "DELETE FROM vehiculo WHERE id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setInt(1, mVehiculo.getId());
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }

    // Validaciones
    public boolean mismoTrabajador(int index, MTrabajador mTrabajadorActual) {
        return registros.get(index).getId() == mTrabajadorActual.getId_persona();
    }

    public boolean validarInformacion(VPVehiculos formulario) {
        if (formulario.txtPlaca.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el número de placa");
            return false;
        } else if (formulario.comboBoxVehiculoTipo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el tipo de vehículo");
            return false;
        } else if (formulario.comboBoxMarca.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar la marca del vehículo");
            return false;
        } else if (formulario.comboBoxModelo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el modelo del vehículo");
            return false;
        } else if (formulario.txtAno.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el año del vehículo");
            return false;
        } else if (formulario.txtColor.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el color del vehículo");
            return false;
        } else if (formulario.comboBoxEstatus.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el estatus del vehículo");
            return false;
        } else if (formulario.comboBoxDocumentoTipo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el tipo de documento del propietario");
            return false;
        } else if (formulario.txtNDocumento.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el número de documento del propietario");
            return false;
        }
        return true;
    }

}
