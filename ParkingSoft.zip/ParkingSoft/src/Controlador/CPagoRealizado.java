package Controlador;

import Modelo.MPagoRealizado;
import Modelo.MReserva;
import Modelo.MTrabajador;
import Vista.Panel.VPPagoRealizado;
import Vista.VReserva;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CPagoRealizado {

    private Conexion mysql = new Conexion();
    private Connection cn = mysql.conectar();
    public Vector<MPagoRealizado> registros;
    // Pago tipo
    private Vector pagoTipo[] = new Vector[2];
    
    public CPagoRealizado() {
        init();
    }

    private void init() {
        cargarData();
    }

    private void cargarData() {
        String SQL = "SELECT * FROM pago_tipo ORDER BY tipo ASC; ";
        for (int i = 0; i < pagoTipo.length; i++) {
            pagoTipo[i] = new Vector();
        }

        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                pagoTipo[0].add(rs.getInt(1));
                pagoTipo[1].add(rs.getString(2));
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public void montarData(JComboBox combobox) {
        combobox.removeAllItems();
        combobox.addItem("Seleccione");
        for (int i = 0; i < pagoTipo[1].size(); i++) {
            combobox.addItem(pagoTipo[1].get(i));
        }
    }

    public boolean existeReserva(int id) {
        String sSQL = "SELECT * FROM reserva WHERE id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    /*
    public int obtenerIdVehiculo(String placa) {
        try {
            String SQL = "SELECT id FROM vehiculo WHERE placa = ?; ";
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (Exception ex) {
            JOptionPane.showConfirmDialog(null, ex);
        }
        return 0;
    }
    */
    public void cargarDatosPrePago(VPPagoRealizado formulario, int id) {
        String SQL = "SELECT reserva.total AS total_a_pagar, COALESCE(SUM(pago_realizado.nu_monto), 0.00) AS total_pagado, CASE WHEN (COALESCE(SUM(pago_realizado.nu_monto), 0.00) <= reserva.total) THEN 0.00 ELSE (COALESCE(SUM(pago_realizado.nu_monto), 0.00) - reserva.total) END AS cambio FROM reserva LEFT JOIN pago_realizado ON reserva.id = pago_realizado.id_reserva WHERE reserva.id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                formulario.txtTotalPagar.setText(String.valueOf(rs.getDouble("total_a_pagar")));
                formulario.txtTotalPagado.setText(String.valueOf(rs.getDouble("total_pagado")));
                formulario.txtCambio.setText(String.valueOf(rs.getDouble("cambio")));
            } else {
                JOptionPane.showMessageDialog(null, "No existen registros con esa placa", "Aviso", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }
    
    public MPagoRealizado obtenerPagoRealizado(int index) {
        return registros.get(index);
    }
    
    public void mostrar(String buscar, DefaultTableModel defaultTableModel) {
        registros = new Vector();
        while (defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }
        String SQL = "SELECT pago_realizado.id, reserva.id AS id_reserva, pago_realizado.id_pago_tipo, pago_realizado.nu_referencia, pago_tipo.tipo AS pago_tipo, pago_realizado.nu_monto AS nu_pago_realizado, pago_realizado.f_pago AS fecha_pago, reserva.total AS total_a_pagar, SUM(pago_realizado.nu_monto) AS total_pagado, CASE WHEN (SUM(pago_realizado.nu_monto) > reserva.total) THEN (SUM(pago_realizado.nu_monto) - reserva.total) ELSE (reserva.total - SUM(pago_realizado.nu_monto)) END AS cambio FROM reserva INNER JOIN pago_realizado ON reserva.id = pago_realizado.id_reserva INNER JOIN pago_tipo ON pago_realizado.id_pago_tipo = pago_tipo.id INNER JOIN vehiculo ON reserva.id_vehiculo = vehiculo.id WHERE pago_tipo.tipo LIKE ? GROUP BY reserva.id; ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setString(1, "%" + buscar + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MPagoRealizado mPagoRealizado = new MPagoRealizado();
                mPagoRealizado.setId(rs.getInt("id"));
                mPagoRealizado.setId_reserva(rs.getInt("id_reserva"));
                mPagoRealizado.setNu_monto(rs.getDouble("nu_pago_realizado"));
                mPagoRealizado.setF_pago(new Date(rs.getDate("fecha_pago").getTime()));
                mPagoRealizado.getmPagoTipo().setId(rs.getInt("id_pago_tipo"));
                mPagoRealizado.getmPagoTipo().setTipo(rs.getString("pago_tipo"));
                mPagoRealizado.setNu_referencia(rs.getString("nu_referencia"));
                mPagoRealizado.setTotal_a_pagar(rs.getDouble("total_a_pagar"));
                mPagoRealizado.setTotal_pagado(rs.getDouble("total_pagado"));
                mPagoRealizado.setCambio(rs.getDouble("cambio"));
                registros.add(mPagoRealizado);
                
                int id_reserva = mPagoRealizado.getId_reserva();
                String pago_tipo = rs.getString("pago_tipo");
                String nu_pago_realizado = String.valueOf(rs.getDouble("nu_pago_realizado"));
                String fecha_de_pago = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(rs.getDate("fecha_pago"));
                
                defaultTableModel.addRow(new Object[]{registros.size(), id_reserva, pago_tipo, nu_pago_realizado, fecha_de_pago});
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public MPagoRealizado selectRegistro(VPPagoRealizado formulario, int index) {
        MPagoRealizado mPagoRealizado = registros.get(index);
        formulario.txtIdReserva.setText(String.valueOf(mPagoRealizado.getId_reserva()));
        formulario.comboBoxTipoPago.setSelectedItem(mPagoRealizado.getmPagoTipo().getTipo());
        formulario.txtPagar.setText(String.valueOf(mPagoRealizado.getNu_monto()));
        formulario.txtReferencia.setText(mPagoRealizado.getNu_referencia());
        formulario.txtTotalPagar.setText(String.valueOf(mPagoRealizado.getTotal_a_pagar()));
        formulario.txtTotalPagado.setText(String.valueOf(mPagoRealizado.getTotal_pagado()));
        formulario.txtCambio.setText(String.valueOf(mPagoRealizado.getCambio()));
        return mPagoRealizado;
    }
    
    public boolean pagoCompleto(int idReserva) {
        String SQL = "SELECT COALESCE((SUM(pago_realizado.nu_monto) >= reserva.total), 0) FROM reserva LEFT JOIN pago_realizado ON reserva.id = pago_realizado.id_reserva WHERE reserva.id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            // persona
            ps.setInt(1, idReserva);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getBoolean(1);
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    public boolean insertar(MPagoRealizado mPagoRealizado, VPPagoRealizado formulario) {
        // Preparar la data
        mPagoRealizado.getmPagoTipo().setId(Integer.valueOf(pagoTipo[0].get(formulario.comboBoxTipoPago.getSelectedIndex() - 1).toString()));
        
        String SQL = "INSERT INTO pago_realizado (id_reserva, id_pago_tipo, nu_referencia, nu_monto, f_pago) VALUES (?, ?, ?, ?, NOW()); ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            // persona
            ps.setInt(1, mPagoRealizado.getId_reserva());
            ps.setInt(2, mPagoRealizado.getmPagoTipo().getId());
            ps.setString(3, mPagoRealizado.getNu_referencia());
            ps.setDouble(4, mPagoRealizado.getNu_monto());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    public boolean finalizar(MReserva mReserva) {
        String subQuery = "((TIMESTAMPDIFF(MINUTE, reserva.fecha_ingreso, NOW()) / 60) * (SELECT costo FROM reserva_costo WHERE id_vehiculo_tipo = ?))";
        String SQL = "";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            // persona
            ps.setInt(1, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(2, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(3, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(4, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(5, mReserva.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    // Validaciones
    public boolean mismoTrabajador(int index, MTrabajador mTrabajadorActual) {
        return registros.get(index).getId() == mTrabajadorActual.getId_persona();
    }
    
    public boolean validarInformacion(VPPagoRealizado formulario) {
        
        return true;
    }

}
