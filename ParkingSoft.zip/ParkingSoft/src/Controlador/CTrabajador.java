package Controlador;

import Modelo.MTrabajador;
import Vista.Panel.VPTrabajadores;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jhon
 */
public class CTrabajador {

    private Conexion mysql = new Conexion();
    private Connection cn = mysql.conectar();
    private String sSQL = "";
    private String sSQL2 = "";
    public Vector<MTrabajador> registros;
    public Integer totalRegistros;

    // Tipo de documento
    private Vector tipoDocumento[] = new Vector[2];
    // Rol del trabajador
    private Vector rol[] = new Vector[2];
    // Estatus
    private Vector estatus[] = new Vector[2];

    public CTrabajador() {
        init("Documento tipo");
        init("Rol");
        init("Estatus");
    }

    private void init(String tipoData) {
        cargarData(tipoData);
    }

    private void cargarData(String tipoData) {
        Vector vectorData[] = null;
        if (tipoData.equals("Documento tipo")) {
            vectorData = tipoDocumento;
            sSQL = "SELECT * FROM documento_tipo ORDER BY id ASC; ";
        } else if (tipoData.equals("Rol")) {
            vectorData = rol;
            sSQL = "SELECT * FROM trabajador_rol ORDER BY id ASC; ";
        } else if (tipoData.equals("Estatus")) {
            vectorData = estatus;
            sSQL = "SELECT * FROM estatus ORDER BY id ASC; ";
        }
        for (int i = 0; i < vectorData.length; i++) {
            vectorData[i] = new Vector();
        }

        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                vectorData[0].add(rs.getInt(1));
                vectorData[1].add(rs.getString(2));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void montarData(JComboBox combobox, String tipoData) {
        combobox.removeAllItems();
        combobox.addItem("Seleccione");
        Vector[] vectorData = null;
        if (tipoData.equals("Documento tipo")) {
            vectorData = tipoDocumento;
        } else if (tipoData.equals("Rol")) {
            vectorData = rol;
        } else if (tipoData.equals("Estatus")) {
            vectorData = estatus;
        }
        for (int i = 0; i < vectorData[1].size(); i++) {
            combobox.addItem(vectorData[1].get(i));
        }
    }

    public boolean existeUsuario(String user) {
        sSQL = "SELECT id FROM trabajador WHERE user = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, user);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }
    }
    
    public boolean existePersona(String documentoTipo, String nuDocumento) {
        String SQL = "SELECT id FROM persona WHERE nu_documento = ? AND id_documento_tipo = (SELECT id FROM documento_tipo WHERE tipo = ?); ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setString(1, nuDocumento);
            ps.setString(2, documentoTipo);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    public MTrabajador obtenerTrabajador(String user) {
        sSQL = "SELECT p.id AS id_persona, p.nombres, p.apellidos, p.id_documento_tipo, p.nu_documento, documento_tipo.tipo AS documento_tipo, p.direccion, p.telefono, p.celular, p.email, t.id AS id_trabajador, t.id_trabajador_rol, t.id_estatus, t.id_trabajador_contrato, t.sueldo, t.user, t.password, t.salt FROM persona p INNER JOIN trabajador t ON p.id = t.id_persona INNER JOIN documento_tipo ON p.id_documento_tipo = documento_tipo.id WHERE t.user = ? ORDER BY p.nu_documento ASC; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, user);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                MTrabajador mTrabajador = new MTrabajador();
                mTrabajador.setId(rs.getInt("id_trabajador"));
                mTrabajador.setId_persona(rs.getInt("id_persona"));
                mTrabajador.setId_trabajador_rol(rs.getInt("id_trabajador_rol"));
                mTrabajador.setId_estatus(rs.getInt("id_estatus"));
                mTrabajador.setId_trabajador_contrato(rs.getInt("id_trabajador_contrato"));
                mTrabajador.setId_documento_tipo(rs.getInt("id_documento_tipo"));
                mTrabajador.setNombres(rs.getString("nombres"));
                mTrabajador.setApellidos(rs.getString("apellidos"));
                mTrabajador.setNu_documento(rs.getString("nu_documento"));
                mTrabajador.setDocumento_tipo(rs.getString("documento_tipo"));
                mTrabajador.setDireccion(rs.getString("direccion"));
                mTrabajador.setTelefono(rs.getString("telefono"));
                mTrabajador.setCelular(rs.getString("celular"));
                mTrabajador.setEmail(rs.getString("email"));
                mTrabajador.setSueldo(rs.getInt("sueldo"));
                mTrabajador.setUser(rs.getString("user"));
                mTrabajador.setPassword(rs.getString("password"));
                mTrabajador.setSalt(rs.getString("salt"));
                
                return mTrabajador;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }
    
    public MTrabajador obtenerTrabajador(int index) {
        return registros.get(index);    
    }
    
    public void mostrar(String buscar, DefaultTableModel defaultTableModel) {
        registros = new Vector();
        while (defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }
        sSQL = "SELECT p.id AS id_persona, p.nombres, p.apellidos, p.id_documento_tipo, p.nu_documento, documento_tipo.tipo AS documento_tipo, p.direccion, p.telefono, p.celular, p.email, t.id AS id_trabajador, t.id_trabajador_rol, t.id_estatus, t.id_trabajador_contrato, t.sueldo, t.user, t.password, t.salt FROM persona p INNER JOIN trabajador t ON p.id = t.id_persona INNER JOIN documento_tipo ON p.id_documento_tipo = documento_tipo.id WHERE p.nombres LIKE ? OR p.apellidos LIKE ? OR p.nu_documento LIKE ? ORDER BY p.nu_documento ASC; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, "%" + buscar + "%");
            ps.setString(2, "%" + buscar + "%");
            ps.setString(3, "%" + buscar + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MTrabajador mTrabajador = new MTrabajador();
                mTrabajador.setId(rs.getInt("id_trabajador"));
                mTrabajador.setId_persona(rs.getInt("id_persona"));
                mTrabajador.setId_trabajador_rol(rs.getInt("id_trabajador_rol"));
                mTrabajador.setId_estatus(rs.getInt("id_estatus"));
                mTrabajador.setId_trabajador_contrato(rs.getInt("id_trabajador_contrato"));
                mTrabajador.setId_documento_tipo(rs.getInt("id_documento_tipo"));
                mTrabajador.setNombres(rs.getString("nombres"));
                mTrabajador.setApellidos(rs.getString("apellidos"));
                mTrabajador.setNu_documento(rs.getString("nu_documento"));
                mTrabajador.setDocumento_tipo(rs.getString("documento_tipo"));
                mTrabajador.setDireccion(rs.getString("direccion"));
                mTrabajador.setTelefono(rs.getString("telefono"));
                mTrabajador.setCelular(rs.getString("celular"));
                mTrabajador.setEmail(rs.getString("email"));
                mTrabajador.setSueldo(rs.getInt("sueldo"));
                mTrabajador.setUser(rs.getString("user"));
                mTrabajador.setPassword(rs.getString("password"));
                mTrabajador.setSalt(rs.getString("salt"));
                registros.add(mTrabajador);
                
                defaultTableModel.addRow(new Object[]{registros.size(), (mTrabajador.getNombres() + " " + mTrabajador.getApellidos()), mTrabajador.getNu_documento()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public MTrabajador selectRegistro(VPTrabajadores formulario, int index) {
        MTrabajador mTrabajador = registros.get(index);
        formulario.txtNombres.setText(mTrabajador.getNombres());
        formulario.txtApellidos.setText(mTrabajador.getApellidos());
        formulario.comboBoxTipoDocumento.setSelectedItem(mTrabajador.getDocumento_tipo());
        formulario.txtNDocumento.setText(mTrabajador.getNu_documento());
        formulario.txtDireccion.setText(mTrabajador.getDireccion());
        formulario.txtTelefono.setText(mTrabajador.getTelefono());
        formulario.txtCelular.setText(mTrabajador.getCelular());
        formulario.txtEmail.setText(mTrabajador.getEmail());
        formulario.txtSueldo.setText(String.valueOf(mTrabajador.getSueldo()));
        formulario.txtUsuario.setText(mTrabajador.getUser());
        formulario.txtPassword.setText("P_A_S_S_W_O_R_D");
        formulario.comboBoxRol.setSelectedIndex(rol[0].indexOf(mTrabajador.getId_trabajador_rol()) + 1);
        formulario.comboBoxEstatus.setSelectedIndex(estatus[0].indexOf(mTrabajador.getId_estatus()) + 1);
        return mTrabajador;
    }
    
    public boolean insertar(MTrabajador mTrabajador, VPTrabajadores formulario) {
        sSQL = "INSERT INTO persona (nombres, apellidos, id_documento_tipo, nu_documento, direccion, telefono, celular, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?); ";
        sSQL2 = "INSERT INTO trabajador (id_persona, id_trabajador_rol, id_estatus, id_trabajador_contrato, sueldo, user, password, salt) VALUES ((SELECT MAX(id) FROM persona), ?, ?, ?, ?, ?, ? ,?); ";
        // Preparar la data de los ids
        mTrabajador.setId_documento_tipo(Integer.valueOf(tipoDocumento[0].get(formulario.comboBoxTipoDocumento.getSelectedIndex() - 1).toString()));
        mTrabajador.setId_trabajador_rol(Integer.valueOf(rol[0].get(formulario.comboBoxRol.getSelectedIndex() - 1).toString()));
        mTrabajador.setId_estatus(Integer.valueOf(estatus[0].get(formulario.comboBoxEstatus.getSelectedIndex() - 1).toString()));
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            PreparedStatement ps2 = cn.prepareStatement(sSQL2);
            // persona
            ps.setString(1, mTrabajador.getNombres());
            ps.setString(2, mTrabajador.getApellidos());
            ps.setInt(3, mTrabajador.getId_documento_tipo());
            ps.setString(4, mTrabajador.getNu_documento());
            ps.setString(5, mTrabajador.getDireccion());
            ps.setString(6, mTrabajador.getTelefono());
            ps.setString(7, mTrabajador.getCelular());
            ps.setString(8, mTrabajador.getEmail());
            // trabajador
            ps2.setInt(1, mTrabajador.getId_trabajador_rol());
            ps2.setInt(2, mTrabajador.getId_estatus());
            ps2.setInt(3, mTrabajador.getId_trabajador_contrato());
            ps2.setDouble(4, mTrabajador.getSueldo());
            ps2.setString(5, mTrabajador.getUser());
            ps2.setString(6, mTrabajador.getPassword());
            ps2.setString(7, mTrabajador.getSalt());
            int rs1 = ps.executeUpdate();
            if (rs1 > 0) {
                System.out.println("Flag 1");
                int rs2 = ps2.executeUpdate();
                if (rs2 > 0) {
                    System.out.println("Flag 2");
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }
    }

    public boolean editar(MTrabajador mTrabajador, VPTrabajadores formulario) {
        sSQL = "UPDATE persona SET nombres = ?, apellidos = ?, id_documento_tipo = ?, nu_documento = ?, direccion = ?, telefono = ?, celular = ?, email = ? WHERE id = ?; ";
        sSQL2 = "UPDATE trabajador SET id_trabajador_rol = ?, id_estatus = ?, sueldo = ?, user = ?, password = ? WHERE id = ?; ";
        // Preparar la data de los ids
        mTrabajador.setId_documento_tipo(Integer.valueOf(tipoDocumento[0].get(formulario.comboBoxTipoDocumento.getSelectedIndex() - 1).toString()));
        mTrabajador.setId_trabajador_rol(Integer.valueOf(rol[0].get(formulario.comboBoxRol.getSelectedIndex() - 1).toString()));
        mTrabajador.setId_estatus(Integer.valueOf(estatus[0].get(formulario.comboBoxEstatus.getSelectedIndex() - 1).toString()));
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            PreparedStatement ps2 = cn.prepareStatement(sSQL2);
            // persona
            ps.setString(1, mTrabajador.getNombres());
            ps.setString(2, mTrabajador.getApellidos());
            ps.setInt(3, mTrabajador.getId_documento_tipo());
            ps.setString(4, mTrabajador.getNu_documento());
            ps.setString(5, mTrabajador.getDireccion());
            ps.setString(6, mTrabajador.getTelefono());
            ps.setString(7, mTrabajador.getCelular());
            ps.setString(8, mTrabajador.getEmail());
            ps.setInt(9, mTrabajador.getId_persona());
            System.out.println();
            // trabajador
            ps2.setInt(1, mTrabajador.getId_trabajador_rol());
            ps2.setInt(2, mTrabajador.getId_estatus());
            ps2.setDouble(3, mTrabajador.getSueldo());
            ps2.setString(4, mTrabajador.getUser());
            ps2.setString(5, mTrabajador.getPassword());
            ps2.setInt(6, mTrabajador.getId());
            int rs1 = ps.executeUpdate();
            if (rs1 > 0) {
                System.out.println("Flag 1");
                int rs2 = ps2.executeUpdate();
                if (rs2 > 0) {
                    System.out.println("Flag 2");
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }
    }

    public boolean eliminar(MTrabajador mTrabajador) {
        sSQL = "DELETE FROM persona WHERE id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setInt(1, mTrabajador.getId_persona());
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }
    
    // Validaciones
    public boolean mismoTrabajador(int index, MTrabajador mTrabajadorActual) {
        return registros.get(index).getId() == mTrabajadorActual.getId();
    }
    
    public boolean validarInformacion(VPTrabajadores formulario) {
        if (formulario.txtNombres.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar los nombres");
            return false;
        } else if (formulario.txtApellidos.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar los apellidos");
            return false;
        } else if (formulario.comboBoxTipoDocumento.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el tipo de documento");
            return false;
        } else if (formulario.txtNDocumento.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el número de documento");
            return false;
        } else if (formulario.txtDireccion.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar la dirección");
            return false;
        } else if (formulario.txtCelular.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el celular");
            return false;
        } else if (formulario.txtEmail.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el email");
            return false;
        } else if (formulario.txtSueldo.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el sueldo");
            return false;
        } else if (formulario.txtUsuario.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el usuario");
            return false;
        } else if (String.valueOf(formulario.txtPassword.getPassword()).strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar la contraseña");
            return false;
        } else if (formulario.comboBoxRol.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el rol");
            return false;
        } else if (formulario.comboBoxEstatus.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el estatus");
            return false;
        }
        return true;
    }

}
