package Controlador;

import Modelo.MReserva;
import Modelo.MTrabajador;
import Vista.VReserva;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CReserva {

    private Conexion mysql = new Conexion();
    private Connection cn = mysql.conectar();
    public Vector<MReserva> registros;
    private double iva = 0.16;
    
    public CReserva() {
        
    }
    
    public boolean placaLibre(String placa) {
        String sSQL = "SELECT reserva.fecha_salida IS NULL FROM reserva INNER JOIN vehiculo ON reserva.id_vehiculo = vehiculo.id WHERE reserva.id = (SELECT MAX(id) FROM reserva WHERE id_vehiculo = vehiculo.id) AND vehiculo.placa = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return !rs.getBoolean(1);
            }
        } catch (Exception e) {
            System.out.println("CReserva.placaLibre()");
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
        return true;
    }

    public boolean existePlaca(String placa) {
        String sSQL = "SELECT id FROM vehiculo WHERE placa = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            System.out.println("CReserva.existePlaca()");
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    public int obtenerIdVehiculo(String placa) {
        try {
            String SQL = "SELECT id FROM vehiculo WHERE placa = ?; ";
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (Exception ex) {
            JOptionPane.showConfirmDialog(null, ex);
        }
        return 0;
    }
    
    public void cargarDatosPreReserva(VReserva formulario, String placa) {
        String SQL = "SELECT reserva_costo.costo FROM reserva_costo INNER JOIN vehiculo ON reserva_costo.id_vehiculo_tipo = vehiculo.id_vehiculo_tipo WHERE vehiculo.placa = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                formulario.txtPlaca.setEnabled(false);
                formulario.txtCostoHora.setText(String.valueOf(rs.getDouble("costo")));
            } else {
                JOptionPane.showMessageDialog(null, "No existen registros con esa placa", "Aviso", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }
    
    public MReserva obtenerReserva(int index) {
        return registros.get(index);
    }
    
    public void mostrar(String buscar, DefaultTableModel defaultTableModel) {
        registros = new Vector();
        while (defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }
        // 21:11:30 
        // 21:12:20 -> Cuando los segundo son menores, aumentar 1
        // CASE WHEN (TIMESTAMPDIFF(SECOND, reserva.fecha_ingreso, NOW())) THEN () ELSE () END
        String subQuery = "((TIMESTAMPDIFF(MINUTE, reserva.fecha_ingreso, NOW()) / 60) * reserva_costo.costo)";
        String sSQL = "SELECT reserva.id, vehiculo.placa, vehiculo_tipo.id AS id_vehiculo_tipo, persona.nombres, persona.apellidos, reserva.fecha_ingreso, reserva.fecha_salida, reserva_costo.costo AS costo_hora, reserva.subtotal, reserva.iva, CASE WHEN reserva.fecha_salida IS NULL THEN (" + subQuery + " + (" + subQuery + " * " + iva + ")) ELSE (reserva.total) END AS total FROM reserva INNER JOIN vehiculo ON reserva.id_vehiculo = vehiculo.id INNER JOIN vehiculo_tipo ON vehiculo.id_vehiculo_tipo = vehiculo_tipo.id INNER JOIN reserva_costo ON vehiculo.id_vehiculo_tipo = reserva_costo.id_vehiculo_tipo INNER JOIN persona ON vehiculo.id_propietario = persona.id WHERE persona.nombres LIKE ? OR persona.apellidos LIKE ? OR persona.nu_documento LIKE ? OR vehiculo.placa LIKE ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, "%" + buscar + "%");
            ps.setString(2, "%" + buscar + "%");
            ps.setString(3, "%" + buscar + "%");
            ps.setString(4, "%" + buscar + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MReserva mReserva = new MReserva();
                mReserva.setId(rs.getInt("id"));
                mReserva.setIva(rs.getDouble("iva"));
                mReserva.setSubtotal(rs.getDouble("subtotal"));
                mReserva.setCosto_hora(rs.getDouble("costo_hora"));
                mReserva.setTotal(rs.getDouble("total"));
                mReserva.setFecha_ingreso(new Date(rs.getDate("fecha_ingreso").getTime()));
                if (rs.getDate("fecha_salida") != null) {
                    mReserva.setFecha_salida(new Date(rs.getDate("fecha_salida").getTime()));
                }
                mReserva.getmVehiculo().setPlaca(rs.getString("placa"));
                mReserva.getmVehiculo().getmVehiculoTipo().setId(rs.getInt("id_vehiculo_tipo"));
                mReserva.getmVehiculo().getmPropietario().setNombres(rs.getString("nombres"));
                mReserva.getmVehiculo().getmPropietario().setApellidos(rs.getString("apellidos"));
                registros.add(mReserva);
                
                String placa = rs.getString("placa");
                String propietario = rs.getString("nombres") + " " + rs.getString("apellidos");
                String fecha_ingreso = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(mReserva.getFecha_ingreso());
                String fecha_salida = rs.getDate("fecha_salida") == null? "Sin salir" : new SimpleDateFormat("dd/MM/yyyy HH:mm").format(rs.getDate("fecha_salida"));
                
                defaultTableModel.addRow(new Object[]{mReserva.getId(), placa, propietario, fecha_ingreso, fecha_salida});
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public MReserva selectRegistro(VReserva vReserva, int index) {
        MReserva mReserva = registros.get(index);
        vReserva.txtNRegistro.setText(String.valueOf(mReserva.getId()));
        vReserva.txtPlaca.setEnabled(false);
        vReserva.txtPlaca.setText(mReserva.getmVehiculo().getPlaca());
        vReserva.txtCostoHora.setText(String.valueOf(mReserva.getCosto_hora()));
        vReserva.txtCostoTotal.setText(String.valueOf(mReserva.getTotal()));
        return mReserva;
    }
    
    public boolean insertar(MReserva mReserva, VReserva formulario) {
        // Preparar la data
        mReserva.getmVehiculo().setId(obtenerIdVehiculo(formulario.txtPlaca.getText()));
        String sSQL = "INSERT INTO reserva (id_vehiculo, id_trabajador, fecha_ingreso, subtotal, iva, total) VALUES (?, ?, NOW(), ?, ?, ?); ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            // persona
            ps.setInt(1, mReserva.getmVehiculo().getId());
            ps.setInt(2, mReserva.getmTrabajador().getId());
            ps.setDouble(3, 0.00);
            ps.setDouble(4, 0.00);
            ps.setDouble(5, 0.00);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    public boolean finalizar(MReserva mReserva) {
        String subQuery = "((TIMESTAMPDIFF(MINUTE, reserva.fecha_ingreso, NOW()) / 60) * (SELECT costo FROM reserva_costo WHERE id_vehiculo_tipo = ?))";
        String SQL = "UPDATE reserva SET fecha_salida = NOW(), subtotal = " + subQuery + ", iva = (" + subQuery + " * " + iva + "), total = (" + subQuery + " + (" + subQuery + " * " + iva + ")) WHERE id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            // persona
            ps.setInt(1, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(2, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(3, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(4, mReserva.getmVehiculo().getmVehiculoTipo().getId());
            ps.setInt(5, mReserva.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    public boolean eliminar(MReserva mReserva) {
        String SQL = "DELETE FROM reserva WHERE id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setInt(1, mReserva.getId());
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    // Validaciones
    public boolean mismoTrabajador(int index, MTrabajador mTrabajadorActual) {
        return registros.get(index).getId() == mTrabajadorActual.getId_persona();
    }
    
    public boolean validarInformacion(VReserva formulario) {
        if (formulario.txtPlaca.isEnabled()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar la placa");
            return false;
        }
        return true;
    }

}
