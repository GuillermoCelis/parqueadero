package Controlador;

import Modelo.MPersona;
import Modelo.MTrabajador;
import Vista.Panel.VPClientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CCliente {

    private Conexion mysql = new Conexion();
    private Connection cn = mysql.conectar();
    private String sSQL = "";
    private String sSQL2 = "";
    public Vector<MPersona> registros;
    public Integer totalRegistros;
    
    // Tipo de documento
    private Vector tipoDocumento[] = new Vector[2];

    public CCliente() {
        init("Documento tipo");
    }

    private void init(String tipoData) {
        cargarData(tipoData);
    }

    private void cargarData(String tipoData) {
        Vector vectorData[] = null;
        if (tipoData.equals("Documento tipo")) {
            vectorData = tipoDocumento;
            sSQL = "SELECT * FROM documento_tipo ORDER BY id ASC; ";
        }
        for (int i = 0; i < vectorData.length; i++) {
            vectorData[i] = new Vector();
        }

        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                vectorData[0].add(rs.getInt(1));
                vectorData[1].add(rs.getString(2));
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public void montarData(JComboBox combobox, String tipoData) {
        combobox.removeAllItems();
        combobox.addItem("Seleccione");
        Vector[] vectorData = null;
        if (tipoData.equals("Documento tipo")) {
            vectorData = tipoDocumento;
        }
        for (int i = 0; i < vectorData[1].size(); i++) {
            combobox.addItem(vectorData[1].get(i));
        }
    }

    public boolean existeCliente(String user) {
        sSQL = "SELECT id FROM trabajador WHERE user = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, user);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    public boolean existePersona(String documentoTipo, String nuDocumento) {
        String SQL = "SELECT id FROM persona WHERE nu_documento = ? AND id_documento_tipo = (SELECT id FROM documento_tipo WHERE tipo = ?); ";
        try {
            PreparedStatement ps = cn.prepareStatement(SQL);
            ps.setString(1, nuDocumento);
            ps.setString(2, documentoTipo);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    public MPersona obtenerCliente(String nu_documento) {
        for (MPersona persona : registros) {
            if (persona.getNu_documento().equals(nu_documento)) {
                return persona;
            }
        }
        return null;
    }
    
    public MPersona obtenerCliente(int index) {
        return registros.get(index);    
    }
    
    public void mostrar(String buscar, DefaultTableModel defaultTableModel) {
        registros = new Vector();
        while (defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }
        sSQL = "SELECT p.id, p.nombres, p.apellidos, p.id_documento_tipo, p.nu_documento, documento_tipo.tipo AS documento_tipo, p.direccion, p.telefono, p.celular, p.email FROM persona p INNER JOIN documento_tipo ON p.id_documento_tipo = documento_tipo.id WHERE (p.nombres LIKE ? OR p.apellidos LIKE ? OR p.nu_documento LIKE ?) AND p.id NOT IN (SELECT id_persona FROM trabajador) ORDER BY p.nu_documento ASC; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setString(1, "%" + buscar + "%");
            ps.setString(2, "%" + buscar + "%");
            ps.setString(3, "%" + buscar + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MPersona mPersona = new MPersona();
                mPersona.setId(rs.getInt("id"));
                mPersona.setId_documento_tipo(rs.getInt("id_documento_tipo"));
                mPersona.setNombres(rs.getString("nombres"));
                mPersona.setApellidos(rs.getString("apellidos"));
                mPersona.setNu_documento(rs.getString("nu_documento"));
                mPersona.setDocumento_tipo(rs.getString("documento_tipo"));
                mPersona.setDireccion(rs.getString("direccion"));
                mPersona.setTelefono(rs.getString("telefono"));
                mPersona.setCelular(rs.getString("celular"));
                mPersona.setEmail(rs.getString("email"));
                registros.add(mPersona);
                
                defaultTableModel.addRow(new Object[]{registros.size(), (mPersona.getNombres() + " " + mPersona.getApellidos()), mPersona.getNu_documento()});
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }

    public MPersona selectRegistro(VPClientes formulario, int index) {
        MPersona mPersona = registros.get(index);
        formulario.txtNombres.setText(mPersona.getNombres());
        formulario.txtApellidos.setText(mPersona.getApellidos());
        formulario.comboBoxTipoDocumento.setSelectedItem(mPersona.getDocumento_tipo());
        formulario.txtNDocumento.setText(mPersona.getNu_documento());
        formulario.txtDireccion.setText(mPersona.getDireccion());
        formulario.txtTelefono.setText(mPersona.getTelefono());
        formulario.txtCelular.setText(mPersona.getCelular());
        formulario.txtEmail.setText(mPersona.getEmail());
        return mPersona;
    }
    
    public boolean insertar(MPersona mPersona, VPClientes formulario) {
        sSQL = "INSERT INTO persona (nombres, apellidos, id_documento_tipo, nu_documento, direccion, telefono, celular, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?); ";
        // Preparar la data de los ids
        mPersona.setId_documento_tipo(Integer.valueOf(tipoDocumento[0].get(formulario.comboBoxTipoDocumento.getSelectedIndex() - 1).toString()));
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            PreparedStatement ps2 = cn.prepareStatement(sSQL2);
            // persona
            ps.setString(1, mPersona.getNombres());
            ps.setString(2, mPersona.getApellidos());
            ps.setInt(3, mPersona.getId_documento_tipo());
            ps.setString(4, mPersona.getNu_documento());
            ps.setString(5, mPersona.getDireccion());
            ps.setString(6, mPersona.getTelefono());
            ps.setString(7, mPersona.getCelular());
            ps.setString(8, mPersona.getEmail());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean editar(MPersona mPersona, VPClientes formulario) {
        sSQL = "UPDATE persona SET nombres = ?, apellidos = ?, id_documento_tipo = ?, nu_documento = ?, direccion = ?, telefono = ?, celular = ?, email = ? WHERE id = ?; ";
        // Preparar la data de los ids
        mPersona.setId_documento_tipo(Integer.valueOf(tipoDocumento[0].get(formulario.comboBoxTipoDocumento.getSelectedIndex() - 1).toString()));
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            PreparedStatement ps2 = cn.prepareStatement(sSQL2);
            // persona
            ps.setString(1, mPersona.getNombres());
            ps.setString(2, mPersona.getApellidos());
            ps.setInt(3, mPersona.getId_documento_tipo());
            ps.setString(4, mPersona.getNu_documento());
            ps.setString(5, mPersona.getDireccion());
            ps.setString(6, mPersona.getTelefono());
            ps.setString(7, mPersona.getCelular());
            ps.setString(8, mPersona.getEmail());
            ps.setInt(9, mPersona.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean eliminar(MPersona mPersona) {
        sSQL = "DELETE FROM persona WHERE id = ?; ";
        try {
            PreparedStatement ps = cn.prepareStatement(sSQL);
            ps.setInt(1, mPersona.getId());
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return false;
    }
    
    // Validaciones
    public boolean mismoTrabajador(int index, MTrabajador mTrabajadorActual) {
        return registros.get(index).getId() == mTrabajadorActual.getId_persona();
    }
    
    public boolean validarInformacion(VPClientes formulario) {
        if (formulario.txtNombres.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar los nombres");
            return false;
        } else if (formulario.txtApellidos.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar los apellidos");
            return false;
        } else if (formulario.comboBoxTipoDocumento.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el tipo de documento");
            return false;
        } else if (formulario.txtNDocumento.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el número de documento");
            return false;
        } else if (formulario.txtDireccion.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar la dirección");
            return false;
        } else if (formulario.txtCelular.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el celular");
            return false;
        } else if (formulario.txtEmail.getText().strip().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el email");
            return false;
        }
        return true;
    }

}
