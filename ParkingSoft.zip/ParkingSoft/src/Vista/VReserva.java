package Vista;

import Controlador.CReserva;
import Modelo.MReserva;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VReserva extends javax.swing.JFrame {
    
    CReserva cReserva = new CReserva();
    
    public VReserva() {
        FlatLightLaf.setup();
        initComponents();
        init();
    }
    
    private void init() {
        initEvents();
        setBackground(new Color(0, 0, 0, 0));
        buscar("");
        // Cargar data
        cargarData();
    }
    
    private void cargarData() {
        
    }
    
    private void initEvents() {
        tblReservas.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (tblReservas.getSelectedRow() >= 0) {
                    txtNRegistro.setText(String.valueOf(cReserva.registros.get(tblReservas.getSelectedRow()).getId()));
                    btnIngresar.setText("Finalizar");
                    cReserva.selectRegistro(VReserva.this, tblReservas.getSelectedRow());
                }
            }
        });
    }
    
    private void clearData() {
        tblReservas.getSelectionModel().clearSelection();
        txtNRegistro.setText("Seleccione un registro");
        txtPlaca.setEnabled(true);
        txtPlaca.setText("");
        txtCostoHora.setText("");
        txtCostoTotal.setText("");
        
        btnIngresar.setText("Ingresar");
    }
    
    private void buscar(String buscar){
        try {
            cReserva.mostrar(buscar, (DefaultTableModel) tblReservas.getModel());
            lblRegistros.setText("Registros: " + tblReservas.getRowCount());
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(rootPane, e);
        }
    }
    
    private void borrarReserva() {
        int index = tblReservas.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un registro a borrar");
            return;
        }
        if (JOptionPane.showConfirmDialog(null, "¿Seguro que desea borrar el registro?", "Aviso", JOptionPane.YES_NO_OPTION) == 0) {
            if (cReserva.eliminar(cReserva.obtenerReserva(index))) {
                clearData();
                buscar(txtBuscar.getText());
                JOptionPane.showMessageDialog(null, "Registro eliminado satisfactoriamente", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un problema eliminando el registro", "Aviso", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        vPLoginBackground1 = new Vista.Componentes.PanelRound();
        vPLogo2 = new Vista.Panel.VPLogo();
        btnVolver = new Vista.Componentes.LabelRound();
        panelRound1 = new Vista.Componentes.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblReservas = new javax.swing.JTable();
        txtBuscar = new Vista.Componentes.CustomTextField();
        btnBorrarTabla = new Vista.Componentes.LabelRound();
        lblRegistros = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        formulario = new Vista.Componentes.PanelRound();
        btnIngresar = new Vista.Componentes.LabelRound();
        lblRegistros1 = new javax.swing.JLabel();
        txtNRegistro = new Vista.Componentes.CustomTextField();
        lblRegistros2 = new javax.swing.JLabel();
        txtPlaca = new Vista.Componentes.CustomTextField();
        jSeparator1 = new javax.swing.JSeparator();
        lblRegistros3 = new javax.swing.JLabel();
        txtCostoHora = new Vista.Componentes.CustomTextField();
        jSeparator2 = new javax.swing.JSeparator();
        lblRegistros4 = new javax.swing.JLabel();
        txtCostoTotal = new Vista.Componentes.CustomTextField();
        btnLimpiarFormulario = new Vista.Componentes.LabelRound();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        vPLoginBackground1.setBackground(new java.awt.Color(153, 230, 235));
        vPLoginBackground1.setSP_gradientColor_1(new java.awt.Color(153, 248, 226));
        vPLoginBackground1.setSP_gradientColor_2(new java.awt.Color(153, 202, 248));

        vPLogo2.setBackground(new java.awt.Color(153, 230, 235));

        btnVolver.setBackground(new java.awt.Color(20, 117, 171));
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnVolver.setText("Volver");
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnVolverMousePressed(evt);
            }
        });

        panelRound1.setBackground(new java.awt.Color(173, 237, 255));

        tblReservas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Placa", "Propietario", "Fecha inicio", "Fecha salida"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblReservas.setFillsViewportHeight(true);
        tblReservas.setRowHeight(25);
        tblReservas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(tblReservas);
        if (tblReservas.getColumnModel().getColumnCount() > 0) {
            tblReservas.getColumnModel().getColumn(0).setMinWidth(35);
            tblReservas.getColumnModel().getColumn(0).setPreferredWidth(35);
            tblReservas.getColumnModel().getColumn(0).setMaxWidth(35);
            tblReservas.getColumnModel().getColumn(1).setMinWidth(100);
            tblReservas.getColumnModel().getColumn(1).setPreferredWidth(100);
            tblReservas.getColumnModel().getColumn(1).setMaxWidth(100);
            tblReservas.getColumnModel().getColumn(3).setMinWidth(125);
            tblReservas.getColumnModel().getColumn(3).setPreferredWidth(125);
            tblReservas.getColumnModel().getColumn(3).setMaxWidth(125);
            tblReservas.getColumnModel().getColumn(4).setMinWidth(125);
            tblReservas.getColumnModel().getColumn(4).setPreferredWidth(125);
            tblReservas.getColumnModel().getColumn(4).setMaxWidth(125);
        }

        txtBuscar.setText("");
        txtBuscar.setSP_placeholder("Ingrese el dato a buscar");
        txtBuscar.setOpaque(false);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        btnBorrarTabla.setBackground(new java.awt.Color(20, 117, 171));
        btnBorrarTabla.setForeground(new java.awt.Color(255, 255, 255));
        btnBorrarTabla.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnBorrarTabla.setText("Borrar");
        btnBorrarTabla.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBorrarTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnBorrarTablaMousePressed(evt);
            }
        });

        lblRegistros.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRegistros.setText("Registros: 0");

        javax.swing.GroupLayout panelRound1Layout = new javax.swing.GroupLayout(panelRound1);
        panelRound1.setLayout(panelRound1Layout);
        panelRound1Layout.setHorizontalGroup(
            panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound1Layout.createSequentialGroup()
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 266, Short.MAX_VALUE)
                        .addComponent(lblRegistros))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnBorrarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panelRound1Layout.setVerticalGroup(
            panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(lblRegistros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBorrarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Reservas");

        formulario.setBackground(new java.awt.Color(173, 237, 255));

        btnIngresar.setBackground(new java.awt.Color(20, 117, 171));
        btnIngresar.setForeground(new java.awt.Color(255, 255, 255));
        btnIngresar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnIngresar.setText("Ingresar");
        btnIngresar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnIngresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnIngresarMousePressed(evt);
            }
        });

        lblRegistros1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros1.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros1.setText("Registro");

        txtNRegistro.setEditable(false);
        txtNRegistro.setForeground(new java.awt.Color(255, 255, 255));
        txtNRegistro.setText("Seleccione un registro");
        txtNRegistro.setSP_placeholder("Seleccione un registro");
        txtNRegistro.setEnabled(false);
        txtNRegistro.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtNRegistro.setOpaque(false);

        lblRegistros2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros2.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros2.setText("Placa");

        txtPlaca.setText("");
        txtPlaca.setSP_placeholder("Ingrese el dato a buscar");
        txtPlaca.setOpaque(false);
        txtPlaca.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPlacaKeyReleased(evt);
            }
        });

        lblRegistros3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros3.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros3.setText("Costo hora");

        txtCostoHora.setEditable(false);
        txtCostoHora.setText("");
        txtCostoHora.setSP_placeholder("Ingrese el dato a buscar");
        txtCostoHora.setEnabled(false);
        txtCostoHora.setOpaque(false);

        lblRegistros4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros4.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros4.setText("Costo total");

        txtCostoTotal.setEditable(false);
        txtCostoTotal.setText("");
        txtCostoTotal.setSP_placeholder("Ingrese el dato a buscar");
        txtCostoTotal.setEnabled(false);
        txtCostoTotal.setOpaque(false);

        btnLimpiarFormulario.setBackground(new java.awt.Color(20, 117, 171));
        btnLimpiarFormulario.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiarFormulario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnLimpiarFormulario.setText("Limpiar");
        btnLimpiarFormulario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpiarFormulario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnLimpiarFormularioMousePressed(evt);
            }
        });

        javax.swing.GroupLayout formularioLayout = new javax.swing.GroupLayout(formulario);
        formulario.setLayout(formularioLayout);
        formularioLayout.setHorizontalGroup(
            formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(formularioLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(formularioLayout.createSequentialGroup()
                        .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(formularioLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(lblRegistros1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblRegistros2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtPlaca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE))
                        .addGap(12, 12, 12))
                    .addGroup(formularioLayout.createSequentialGroup()
                        .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1)
                            .addGroup(formularioLayout.createSequentialGroup()
                                .addComponent(lblRegistros3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCostoHora, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, formularioLayout.createSequentialGroup()
                        .addComponent(jSeparator2)
                        .addContainerGap())
                    .addGroup(formularioLayout.createSequentialGroup()
                        .addComponent(lblRegistros4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCostoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, formularioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnLimpiarFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        formularioLayout.setVerticalGroup(
            formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, formularioLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(txtNRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros2, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(txtPlaca, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros3, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(txtCostoHora, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros4, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(txtCostoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(70, 70, 70)
                .addGroup(formularioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpiarFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout vPLoginBackground1Layout = new javax.swing.GroupLayout(vPLoginBackground1);
        vPLoginBackground1.setLayout(vPLoginBackground1Layout);
        vPLoginBackground1Layout.setHorizontalGroup(
            vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                        .addContainerGap(206, Short.MAX_VALUE)
                        .addComponent(vPLogo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 193, Short.MAX_VALUE))
                    .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(formulario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelRound1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, vPLoginBackground1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        vPLoginBackground1Layout.setVerticalGroup(
            vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(vPLogo2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRound1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(formulario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(vPLoginBackground1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(vPLoginBackground1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVolverMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VInicio().setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverMousePressed

    private void btnIngresarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnIngresarMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            // Validar la información
            if (!cReserva.validarInformacion(this)) {
                return;
            }
            if (tblReservas.getSelectedRow() == -1) {
                // Se quiere añadir
                // reserva
                MReserva mReserva = new MReserva();
                mReserva.getmTrabajador().setId(VInicio.mTrabajadorActual.getId());
                mReserva.setFecha_ingreso(new Date());
                mReserva.setFecha_salida(null);
                
                if (cReserva.insertar(mReserva, this)) {
                    clearData();
                    buscar(txtBuscar.getText());
                    JOptionPane.showMessageDialog(null, "Añadido exitosamente", "Alerta", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Hubo un problema añadiendo", "Alerta", JOptionPane.ERROR_MESSAGE);
                }
                
            } else {
                // Se quiere finalizar
                MReserva mReserva = cReserva.obtenerReserva(tblReservas.getSelectedRow());
                if (mReserva.getFecha_salida() != null) {
                    JOptionPane.showMessageDialog(null, "El registro ya se encuentra finalizado");
                    return;
                }
                if (cReserva.finalizar(mReserva)) {
                    clearData();
                    buscar(txtBuscar.getText());
                    JOptionPane.showMessageDialog(null, "Finalizado exitosamente", "Alerta", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Hubo un problema finalizando", "Alerta", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btnIngresarMousePressed

    private void btnBorrarTablaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBorrarTablaMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            borrarReserva();
        }
    }//GEN-LAST:event_btnBorrarTablaMousePressed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER || txtBuscar.getText().isEmpty()) {
            clearData();
            buscar(txtBuscar.getText());
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtPlacaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPlacaKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!cReserva.existePlaca(txtPlaca.getText())) {
                JOptionPane.showMessageDialog(null, "No existen registros con esa placa", "Aviso", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!cReserva.placaLibre(txtPlaca.getText())) {
                JOptionPane.showMessageDialog(null, "El vehículo no se encuentra libre", "Aviso", JOptionPane.ERROR_MESSAGE);
                return;
            }
            cReserva.cargarDatosPreReserva(this, txtPlaca.getText());
        }
    }//GEN-LAST:event_txtPlacaKeyReleased

    private void btnLimpiarFormularioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarFormularioMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            if (btnLimpiarFormulario.getText().equals("Limpiar")) {
                txtNRegistro.setText("Seleccione un registro");
                clearData();
            }
        }
    }//GEN-LAST:event_btnLimpiarFormularioMousePressed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Vista.Componentes.LabelRound btnBorrarTabla;
    private Vista.Componentes.LabelRound btnIngresar;
    private Vista.Componentes.LabelRound btnLimpiarFormulario;
    private Vista.Componentes.LabelRound btnVolver;
    public Vista.Componentes.PanelRound formulario;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblRegistros;
    private javax.swing.JLabel lblRegistros1;
    private javax.swing.JLabel lblRegistros2;
    private javax.swing.JLabel lblRegistros3;
    private javax.swing.JLabel lblRegistros4;
    private Vista.Componentes.PanelRound panelRound1;
    private javax.swing.JTable tblReservas;
    private Vista.Componentes.CustomTextField txtBuscar;
    public Vista.Componentes.CustomTextField txtCostoHora;
    public Vista.Componentes.CustomTextField txtCostoTotal;
    public Vista.Componentes.CustomTextField txtNRegistro;
    public Vista.Componentes.CustomTextField txtPlaca;
    private Vista.Componentes.PanelRound vPLoginBackground1;
    private Vista.Panel.VPLogo vPLogo2;
    // End of variables declaration//GEN-END:variables
}
