package Vista.Panel;

import Vista.VPagoRealizado;
import static Vista.VPagoRealizado.cPagoRealizado;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class VPPagoRealizado extends javax.swing.JPanel {
    
    public VPPagoRealizado() {
        initComponents();
        init();
    }
    
    private void init() {
        
    }
    
    public void clearData() {
        txtIdReserva.setEnabled(true);
        txtIdReserva.setText("");
        comboBoxTipoPago.setEnabled(false);
        comboBoxTipoPago.setSelectedIndex(0);
        txtPagar.setEnabled(false);
        txtPagar.setText("");
        txtReferencia.setEnabled(false);
        txtReferencia.setText("");
        
        txtTotalPagar.setText("");
        txtTotalPagado.setText("");
        txtCambio.setText("");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblRegistros2 = new javax.swing.JLabel();
        txtIdReserva = new Vista.Componentes.CustomTextField();
        lblRegistros3 = new javax.swing.JLabel();
        txtTotalPagar = new Vista.Componentes.CustomTextField();
        lblRegistros4 = new javax.swing.JLabel();
        txtTotalPagado = new Vista.Componentes.CustomTextField();
        lblRegistros5 = new javax.swing.JLabel();
        txtCambio = new Vista.Componentes.CustomTextField();
        comboBoxTipoPago = new javax.swing.JComboBox<>();
        lblRegistros6 = new javax.swing.JLabel();
        txtPagar = new Vista.Componentes.CustomTextField();
        lblRegistros7 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lblRegistros8 = new javax.swing.JLabel();
        txtReferencia = new Vista.Componentes.CustomTextField();

        setBackground(new java.awt.Color(173, 237, 255));

        lblRegistros2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros2.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros2.setText("Id reserva");

        txtIdReserva.setText("");
        txtIdReserva.setSP_fieldType(Vista.Componentes.CustomTextField.SP_FIELDTYPE.NUMERIC);
        txtIdReserva.setSP_placeholder("Ingrese el dato a buscar");
        txtIdReserva.setOpaque(false);
        txtIdReserva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIdReservaKeyReleased(evt);
            }
        });

        lblRegistros3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros3.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros3.setText("Total a pagar");

        txtTotalPagar.setEditable(false);
        txtTotalPagar.setText("");
        txtTotalPagar.setSP_placeholder("Ingrese el dato a buscar");
        txtTotalPagar.setEnabled(false);
        txtTotalPagar.setOpaque(false);

        lblRegistros4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros4.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros4.setText("Total pagado");

        txtTotalPagado.setEditable(false);
        txtTotalPagado.setText("");
        txtTotalPagado.setSP_placeholder("Ingrese el dato a buscar");
        txtTotalPagado.setEnabled(false);
        txtTotalPagado.setOpaque(false);

        lblRegistros5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros5.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros5.setText("Cambio");

        txtCambio.setEditable(false);
        txtCambio.setText("");
        txtCambio.setSP_placeholder("Ingrese el dato a buscar");
        txtCambio.setEnabled(false);
        txtCambio.setOpaque(false);

        comboBoxTipoPago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione" }));
        comboBoxTipoPago.setEnabled(false);

        lblRegistros6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros6.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros6.setText("Tipo de pago");

        txtPagar.setText("");
        txtPagar.setSP_fieldType(Vista.Componentes.CustomTextField.SP_FIELDTYPE.NUMERIC);
        txtPagar.setSP_placeholder("Ingrese el dato a buscar");
        txtPagar.setEnabled(false);
        txtPagar.setOpaque(false);
        txtPagar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPagarKeyReleased(evt);
            }
        });

        lblRegistros7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros7.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros7.setText("Pagar");

        lblRegistros8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros8.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistros8.setText("Referencia");

        txtReferencia.setText("");
        txtReferencia.setSP_placeholder("Ingrese el dato a buscar");
        txtReferencia.setEnabled(false);
        txtReferencia.setOpaque(false);
        txtReferencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtReferenciaKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblRegistros4, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                            .addComponent(lblRegistros5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblRegistros3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTotalPagado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTotalPagar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtCambio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lblRegistros8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblRegistros2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblRegistros6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblRegistros7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtPagar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtIdReserva, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(comboBoxTipoPago, 0, 151, Short.MAX_VALUE)
                            .addComponent(txtReferencia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIdReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRegistros6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxTipoPago, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReferencia, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotalPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotalPagado, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCambio, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdReservaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdReservaKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Verificar que exista la reserva
            if (!VPagoRealizado.cPagoRealizado.existeReserva(Integer.valueOf(txtIdReserva.getText()))) {
                JOptionPane.showMessageDialog(null, "No existen registros con ese id", "Aviso", JOptionPane.ERROR_MESSAGE);
                return;
            }
            // Verificar que ya se haya pagado completamente
            if (VPagoRealizado.cPagoRealizado.pagoCompleto(Integer.valueOf(txtIdReserva.getText()))) {
                JOptionPane.showMessageDialog(null, "El pago de la reserva se encuentra completo", "Alerta", JOptionPane.ERROR_MESSAGE);
                return;
            }
            txtIdReserva.setEnabled(false);
            comboBoxTipoPago.setEnabled(true);
            txtPagar.setEnabled(true);
            txtReferencia.setEnabled(true);
            VPagoRealizado.cPagoRealizado.cargarDatosPrePago(this, Integer.valueOf(txtIdReserva.getText()));
        }
    }//GEN-LAST:event_txtIdReservaKeyReleased

    private void txtPagarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPagarKeyReleased
        
    }//GEN-LAST:event_txtPagarKeyReleased

    private void txtReferenciaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtReferenciaKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtReferenciaKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JComboBox<String> comboBoxTipoPago;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblRegistros2;
    private javax.swing.JLabel lblRegistros3;
    private javax.swing.JLabel lblRegistros4;
    private javax.swing.JLabel lblRegistros5;
    private javax.swing.JLabel lblRegistros6;
    private javax.swing.JLabel lblRegistros7;
    private javax.swing.JLabel lblRegistros8;
    public Vista.Componentes.CustomTextField txtCambio;
    public Vista.Componentes.CustomTextField txtIdReserva;
    public Vista.Componentes.CustomTextField txtPagar;
    public Vista.Componentes.CustomTextField txtReferencia;
    public Vista.Componentes.CustomTextField txtTotalPagado;
    public Vista.Componentes.CustomTextField txtTotalPagar;
    // End of variables declaration//GEN-END:variables
}
