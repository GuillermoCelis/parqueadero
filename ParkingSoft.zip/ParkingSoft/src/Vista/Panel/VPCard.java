package Vista.Panel;

import Vista.VClientes;
import Vista.VPagoRealizado;
import Vista.VReserva;
import Vista.VTrabajadores;
import Vista.VVehiculo;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class VPCard extends javax.swing.JPanel {

    public VPCard() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardClientes = new Vista.Componentes.Card();
        cardVehiculos = new Vista.Componentes.Card();
        cardPagos = new Vista.Componentes.Card();
        cardTrabajadores = new Vista.Componentes.Card();
        cardReservas = new Vista.Componentes.Card();

        setBackground(new java.awt.Color(172, 241, 253));

        cardClientes.setSP_descripcion("Gestionar clientes");
        cardClientes.setSP_icono(new javax.swing.ImageIcon(getClass().getResource("/Archivos/cliente-32.png"))); // NOI18N
        cardClientes.setSP_titulo("Clientes");
        cardClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cardClientesMousePressed(evt);
            }
        });

        cardVehiculos.setSP_descripcion("Gestionar vehículos");
        cardVehiculos.setSP_icono(new javax.swing.ImageIcon(getClass().getResource("/Archivos/vehículo-32.png"))); // NOI18N
        cardVehiculos.setSP_titulo("Vehículos");
        cardVehiculos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cardVehiculosMousePressed(evt);
            }
        });

        cardPagos.setSP_descripcion("Gestionar pagos");
        cardPagos.setSP_icono(new javax.swing.ImageIcon(getClass().getResource("/Archivos/pago-32.png"))); // NOI18N
        cardPagos.setSP_titulo("Pagos");
        cardPagos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cardPagosMousePressed(evt);
            }
        });

        cardTrabajadores.setSP_descripcion("Gestionar trabajadores");
        cardTrabajadores.setSP_icono(new javax.swing.ImageIcon(getClass().getResource("/Archivos/usuario-32.png"))); // NOI18N
        cardTrabajadores.setSP_titulo("Trabajadores");
        cardTrabajadores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cardTrabajadoresMousePressed(evt);
            }
        });

        cardReservas.setSP_descripcion("Gestionar reservas");
        cardReservas.setSP_icono(new javax.swing.ImageIcon(getClass().getResource("/Archivos/parquímetro-32.png"))); // NOI18N
        cardReservas.setSP_titulo("Reservas");
        cardReservas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cardReservasMousePressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cardTrabajadores, javax.swing.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                    .addComponent(cardVehiculos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cardPagos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cardClientes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cardReservas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardTrabajadores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cardClientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cardVehiculos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cardReservas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cardPagos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cardClientesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cardClientesMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VClientes().setVisible(true);
            ((JFrame) getTopLevelAncestor()).dispose();
        }
    }//GEN-LAST:event_cardClientesMousePressed

    private void cardVehiculosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cardVehiculosMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VVehiculo().setVisible(true);
            ((JFrame) getTopLevelAncestor()).dispose();
        }
    }//GEN-LAST:event_cardVehiculosMousePressed

    private void cardPagosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cardPagosMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VPagoRealizado().setVisible(true);
            ((JFrame) getTopLevelAncestor()).dispose();
        }
    }//GEN-LAST:event_cardPagosMousePressed

    private void cardTrabajadoresMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cardTrabajadoresMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VTrabajadores().setVisible(true);
            ((JFrame) getTopLevelAncestor()).dispose();
        }
    }//GEN-LAST:event_cardTrabajadoresMousePressed

    private void cardReservasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cardReservasMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VReserva().setVisible(true);
            ((JFrame) getTopLevelAncestor()).dispose();
        }
    }//GEN-LAST:event_cardReservasMousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Vista.Componentes.Card cardClientes;
    private Vista.Componentes.Card cardPagos;
    private Vista.Componentes.Card cardReservas;
    private Vista.Componentes.Card cardTrabajadores;
    private Vista.Componentes.Card cardVehiculos;
    // End of variables declaration//GEN-END:variables
}
