package Vista.Componentes;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;

public class LabelRound extends JLabel {
    
    private int SP_arc = 20;
    
    public LabelRound() {
        init();
    }
    
    private void init() {
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(getBackground());
        g2d.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON
        );
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), SP_arc, SP_arc);
        super.paintComponent(g);
    }

    public int getSP_arc() {
        return SP_arc;
    }

    public void setSP_arc(int SP_arc) {
        this.SP_arc = SP_arc;
    }
    
}
