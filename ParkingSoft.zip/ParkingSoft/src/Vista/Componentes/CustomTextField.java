package Vista.Componentes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JTextField;

public class CustomTextField extends JTextField {
    
    private int SP_arc = 20;
    private String SP_placeholder = "Placeholder";
    private Color SP_placeholderForeground = new Color(100, 100, 100);
    private Color SP_foreground = new Color(0, 0, 0);
    private Color SP_borInactiveColor = new Color(100, 100, 100);
    private Color SP_borActiveColor = new Color(255, 255, 255);
    private SP_FIELDTYPE SP_fieldType = SP_FIELDTYPE.ALPHANUMERIC;

    public static enum SP_FIELDTYPE {
        ALPHANUMERIC, 
        TEXT, 
        NUMERIC 
    }
    
    public CustomTextField() {
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        init();
    }
    
    private void init() {
        setText(SP_placeholder);
        setForeground(SP_placeholderForeground);
        setOpaque(true);
        initEvents();
    }
    
    private void initEvents() {
        // Evento de focus
        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (getForeground() == SP_placeholderForeground) {
                    // Está en placeholder, pasando a activo
                    //setText("");
                    //setForeground(SP_foreground);
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if (getText().isEmpty()) {
                    //setText(SP_placeholder);
                    //setForeground(SP_placeholderForeground);
                }
            }
        });
        // Evento keyAdapter
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (SP_fieldType == SP_FIELDTYPE.NUMERIC) {
                    // Solo permitir números
                    if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9')) {
                        if (e.getKeyChar() != '.') {
                            e.consume();
                        } else {
                            if (CustomTextField.this.getText().contains(".")) {
                                e.consume();
                            }
                        }
                    }
                } else if (SP_fieldType == SP_FIELDTYPE.TEXT) {
                    System.out.println("Epa");
                    // Solo permitir texto
                    if (!(Character.toUpperCase(e.getKeyChar()) >= 'A' && Character.toUpperCase(e.getKeyChar()) <= 'Z')) {
                        if (e.getKeyChar() != ' ') {
                            e.consume();
                        }
                    }
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(SP_borInactiveColor);
        g2d.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON
        );
        g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, SP_arc, SP_arc);
    }
    
    // Getters y setters
    public Color getSP_borInactiveColor() {
        return SP_borInactiveColor;
    }

    public void setSP_borInactiveColor(Color SP_borInactiveColor) {
        this.SP_borInactiveColor = SP_borInactiveColor;
    }

    public Color getSP_borActiveColor() {
        return SP_borActiveColor;
    }

    public void setSP_borActiveColor(Color SP_borActiveColor) {
        this.SP_borActiveColor = SP_borActiveColor;
    }

    public int getSP_arc() {
        return SP_arc;
    }

    public void setSP_arc(int SP_arc) {
        this.SP_arc = SP_arc;
    }

    public String getSP_placeholder() {
        return SP_placeholder;
    }

    public void setSP_placeholder(String SP_placeholder) {
        this.SP_placeholder = SP_placeholder;
        if (getForeground() == SP_placeholderForeground) {
            //setText(SP_placeholder);
        }
    }

    public Color getSP_placeholderForeground() {
        return SP_placeholderForeground;
    }

    public void setSP_placeholderForeground(Color SP_placeholderForeground) {
        this.SP_placeholderForeground = SP_placeholderForeground;
        // SP_foreground
        // SP_placeholderForeground
    }

    public Color getSP_foreground() {
        return SP_foreground;
    }

    public void setSP_foreground(Color SP_foreground) {
        this.SP_foreground = SP_foreground;
        if (getForeground() != SP_placeholderForeground) {
            //setForeground(SP_foreground);
        }
    }
    
    public SP_FIELDTYPE getSP_fieldType() {
        return SP_fieldType;
    }

    public void setSP_fieldType(SP_FIELDTYPE SP_fieldType) {
        this.SP_fieldType = SP_fieldType;
    }
    
}
