package Vista.Componentes;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class PanelRound extends javax.swing.JPanel {
    
    private int SP_arc = 20;
    private Color SP_gradientColor_1 = null;
    private Color SP_gradientColor_2 = null;
    
    public PanelRound() {
        initComponents();
        init();
    }
    
    private void init() {
        setOpaque(false);
        initEvents();
    }
    
    private void initEvents() {
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    @Override
    protected void paintComponent(Graphics g) {
        //super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        if (SP_gradientColor_1 == null || SP_gradientColor_2 == null) {
            g2d.setColor(getBackground());
        } else {
            GradientPaint gp = new GradientPaint(getWidth() / 2, 0, SP_gradientColor_1, getWidth() / 2, getHeight(), SP_gradientColor_2);
            g2d.setPaint(gp);
        }
        
        g2d.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON
        );
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), SP_arc, SP_arc);
    }

    public int getSP_arc() {
        return SP_arc;
    }

    public void setSP_arc(int SP_arc) {
        this.SP_arc = SP_arc;
    }

    public Color getSP_gradientColor_1() {
        return SP_gradientColor_1;
    }

    public void setSP_gradientColor_1(Color SP_gradientColor_1) {
        this.SP_gradientColor_1 = SP_gradientColor_1;
    }

    public Color getSP_gradientColor_2() {
        return SP_gradientColor_2;
    }

    public void setSP_gradientColor_2(Color SP_gradientColor_2) {
        this.SP_gradientColor_2 = SP_gradientColor_2;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
