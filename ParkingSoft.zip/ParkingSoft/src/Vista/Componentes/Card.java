package Vista.Componentes;

import java.awt.Cursor;
import javax.swing.Icon;

public class Card extends PanelRound {
    
    private Icon SP_icono = null;
    private String SP_titulo = "Título";
    private String SP_descripcion = "Descripción";
    
    public Card() {
        initComponents();
        init();
    }
    
    private void init() {
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        initEvents();
    }
    
    private void initEvents() {
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblIcono = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        lblDescripcion = new javax.swing.JLabel();

        setBackground(new java.awt.Color(153, 230, 235));

        lblIcono.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Título");

        lblDescripcion.setForeground(new java.awt.Color(255, 255, 255));
        lblDescripcion.setText("Descripción");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblIcono, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDescripcion, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblIcono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblDescripcion, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblIcono;
    private javax.swing.JLabel lblTitulo;
    // End of variables declaration//GEN-END:variables

    public String getSP_titulo() {
        return SP_titulo;
    }

    public void setSP_titulo(String SP_titulo) {
        this.SP_titulo = SP_titulo;
        lblTitulo.setText(SP_titulo);
    }

    public String getSP_descripcion() {
        return SP_descripcion;
    }

    public void setSP_descripcion(String SP_descripcion) {
        this.SP_descripcion = SP_descripcion;
        lblDescripcion.setText(SP_descripcion);
    }

    public Icon getSP_icono() {
        return SP_icono;
    }

    public void setSP_icono(Icon SP_icon) {
        this.SP_icono = SP_icono;
        lblIcono.setIcon(SP_icon);
    }
}
