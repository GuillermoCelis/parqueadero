package Vista;

import Modelo.MTrabajador;
import java.awt.Color;
import javax.swing.SwingUtilities;

public class VInicio extends javax.swing.JFrame {
    
    public static MTrabajador mTrabajadorActual = null;
    
    public VInicio() {
        initComponents();
        init();
    }
    
    public VInicio(MTrabajador mTrabajadorActual) {
        this.mTrabajadorActual = mTrabajadorActual;
        initComponents();
        init();
    }
    
    private void init() {
        setBackground(new Color(0, 0, 0, 0));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        vPLoginBackground1 = new Vista.Componentes.PanelRound();
        jPanel3 = new javax.swing.JPanel();
        btnIniciarSesion2 = new Vista.Componentes.LabelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        vPCard1 = new Vista.Panel.VPCard();
        vPLogo1 = new Vista.Panel.VPLogo();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        vPLoginBackground1.setBackground(new java.awt.Color(153, 230, 235));
        vPLoginBackground1.setSP_gradientColor_1(new java.awt.Color(153, 248, 226));
        vPLoginBackground1.setSP_gradientColor_2(new java.awt.Color(153, 202, 248));

        jPanel3.setBackground(new java.awt.Color(153, 230, 235));
        jPanel3.setOpaque(false);

        btnIniciarSesion2.setBackground(new java.awt.Color(20, 117, 171));
        btnIniciarSesion2.setForeground(new java.awt.Color(255, 255, 255));
        btnIniciarSesion2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnIniciarSesion2.setText("Cerrar sesión");
        btnIniciarSesion2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnIniciarSesion2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnIniciarSesion2MousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnIniciarSesion2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnIniciarSesion2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jScrollPane1.setBackground(new java.awt.Color(172, 241, 253));
        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setViewportView(vPCard1);

        vPLogo1.setBackground(new java.awt.Color(153, 230, 235));

        javax.swing.GroupLayout vPLoginBackground1Layout = new javax.swing.GroupLayout(vPLoginBackground1);
        vPLoginBackground1.setLayout(vPLoginBackground1Layout);
        vPLoginBackground1Layout.setHorizontalGroup(
            vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, vPLoginBackground1Layout.createSequentialGroup()
                .addContainerGap(161, Short.MAX_VALUE)
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(vPLogo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)))
                .addContainerGap(150, Short.MAX_VALUE))
        );
        vPLoginBackground1Layout.setVerticalGroup(
            vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(vPLogo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(vPLoginBackground1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(vPLoginBackground1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnIniciarSesion2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnIniciarSesion2MousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VLogin().setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_btnIniciarSesion2MousePressed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Vista.Componentes.LabelRound btnIniciarSesion2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private Vista.Panel.VPCard vPCard1;
    private Vista.Componentes.PanelRound vPLoginBackground1;
    private Vista.Panel.VPLogo vPLogo1;
    // End of variables declaration//GEN-END:variables
}
