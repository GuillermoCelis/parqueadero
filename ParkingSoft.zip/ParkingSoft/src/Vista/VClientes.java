package Vista;

import Controlador.CCliente;
import Modelo.MPersona;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VClientes extends javax.swing.JFrame {
    
    CCliente cCliente = new CCliente();
    MPersona mClienteSeleccionado = null;
    
    public VClientes() {
        FlatLightLaf.setup();
        initComponents();
        init();
    }
    
    private void init() {
        initEvents();
        setBackground(new Color(0, 0, 0, 0));
        buscar("");
        // Cargar data
        cargarData();
    }
    
    private void cargarData() {
        cCliente.montarData(formulario.comboBoxTipoDocumento, "Documento tipo");
    }
    
    private void initEvents() {
        tblClientes.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (tblClientes.getSelectedRow() >= 0) {
                    txtNRegistro.setText(String.valueOf(cCliente.registros.get(tblClientes.getSelectedRow()).getId()));
                    mClienteSeleccionado = cCliente.selectRegistro(formulario, tblClientes.getSelectedRow());
                } else {
                    mClienteSeleccionado = null;
                }
            }
        });
    }
    
    private void clearData() {
        tblClientes.getSelectionModel().clearSelection();
        txtNRegistro.setText("Seleccione un registro");
        formulario.clearData();
    }
    
    private void buscar(String buscar){
        try {
            cCliente.mostrar(buscar, (DefaultTableModel) tblClientes.getModel());
            lblRegistros.setText("Registros: " + tblClientes.getRowCount());
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(rootPane, e);
        }
    }
    
    private void borrarCliente() {
        int index = tblClientes.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un registro a borrar");
            return;
        }
        if (cCliente.mismoTrabajador(index, VInicio.mTrabajadorActual)) {
            JOptionPane.showMessageDialog(null, "No puedes borrar al mismo trabajador que inició sesión. Debes hacerlo con otra cuenta.");
            return;
        }
        if (JOptionPane.showConfirmDialog(null, "¿Seguro que desea borrar el registro?", "Aviso", JOptionPane.YES_NO_OPTION) == 0) {
            if (cCliente.eliminar(cCliente.obtenerCliente(index))) {
                clearData();
                buscar(txtBuscar.getText());
                JOptionPane.showMessageDialog(null, "Registro eliminado satisfactoriamente", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un problema eliminando el registro", "Aviso", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        vPLoginBackground1 = new Vista.Componentes.PanelRound();
        vPLogo2 = new Vista.Panel.VPLogo();
        btnVolver = new Vista.Componentes.LabelRound();
        panelRound1 = new Vista.Componentes.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        txtBuscar = new Vista.Componentes.CustomTextField();
        btnBorrarTabla = new Vista.Componentes.LabelRound();
        lblRegistros = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        panelRound2 = new Vista.Componentes.PanelRound();
        btnGuardarFormulario = new Vista.Componentes.LabelRound();
        btnLimpiarFormulario = new Vista.Componentes.LabelRound();
        lblRegistros1 = new javax.swing.JLabel();
        txtNRegistro = new Vista.Componentes.CustomTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        formulario = new Vista.Panel.VPClientes();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        vPLoginBackground1.setBackground(new java.awt.Color(153, 230, 235));
        vPLoginBackground1.setSP_gradientColor_1(new java.awt.Color(153, 248, 226));
        vPLoginBackground1.setSP_gradientColor_2(new java.awt.Color(153, 202, 248));

        vPLogo2.setBackground(new java.awt.Color(153, 230, 235));

        btnVolver.setBackground(new java.awt.Color(20, 117, 171));
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnVolver.setText("Volver");
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnVolverMousePressed(evt);
            }
        });

        panelRound1.setBackground(new java.awt.Color(173, 237, 255));

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Nombres y apellidos", "N Documento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblClientes.setFillsViewportHeight(true);
        tblClientes.setRowHeight(25);
        tblClientes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(tblClientes);
        if (tblClientes.getColumnModel().getColumnCount() > 0) {
            tblClientes.getColumnModel().getColumn(0).setMinWidth(35);
            tblClientes.getColumnModel().getColumn(0).setPreferredWidth(35);
            tblClientes.getColumnModel().getColumn(0).setMaxWidth(35);
            tblClientes.getColumnModel().getColumn(2).setMinWidth(100);
            tblClientes.getColumnModel().getColumn(2).setPreferredWidth(100);
            tblClientes.getColumnModel().getColumn(2).setMaxWidth(100);
        }

        txtBuscar.setText("");
        txtBuscar.setSP_placeholder("Ingrese el dato a buscar");
        txtBuscar.setOpaque(false);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        btnBorrarTabla.setBackground(new java.awt.Color(20, 117, 171));
        btnBorrarTabla.setForeground(new java.awt.Color(255, 255, 255));
        btnBorrarTabla.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnBorrarTabla.setText("Borrar");
        btnBorrarTabla.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBorrarTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnBorrarTablaMousePressed(evt);
            }
        });

        lblRegistros.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRegistros.setText("Registros: 0");

        javax.swing.GroupLayout panelRound1Layout = new javax.swing.GroupLayout(panelRound1);
        panelRound1.setLayout(panelRound1Layout);
        panelRound1Layout.setHorizontalGroup(
            panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound1Layout.createSequentialGroup()
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                        .addComponent(lblRegistros))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnBorrarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panelRound1Layout.setVerticalGroup(
            panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(lblRegistros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBorrarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Clientes");

        panelRound2.setBackground(new java.awt.Color(173, 237, 255));

        btnGuardarFormulario.setBackground(new java.awt.Color(20, 117, 171));
        btnGuardarFormulario.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarFormulario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnGuardarFormulario.setText("Guardar");
        btnGuardarFormulario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnGuardarFormulario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnGuardarFormularioMousePressed(evt);
            }
        });

        btnLimpiarFormulario.setBackground(new java.awt.Color(20, 117, 171));
        btnLimpiarFormulario.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiarFormulario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnLimpiarFormulario.setText("Limpiar");
        btnLimpiarFormulario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpiarFormulario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnLimpiarFormularioMousePressed(evt);
            }
        });

        lblRegistros1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblRegistros1.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistros1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRegistros1.setText("Registro");

        txtNRegistro.setEditable(false);
        txtNRegistro.setForeground(new java.awt.Color(255, 255, 255));
        txtNRegistro.setText("Seleccione un registro");
        txtNRegistro.setSP_placeholder("Seleccione un registro");
        txtNRegistro.setEnabled(false);
        txtNRegistro.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtNRegistro.setOpaque(false);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setViewportView(formulario);

        javax.swing.GroupLayout panelRound2Layout = new javax.swing.GroupLayout(panelRound2);
        panelRound2.setLayout(panelRound2Layout);
        panelRound2Layout.setHorizontalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelRound2Layout.createSequentialGroup()
                        .addComponent(btnGuardarFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnLimpiarFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelRound2Layout.createSequentialGroup()
                        .addComponent(lblRegistros1)
                        .addGap(50, 50, 50)
                        .addComponent(txtNRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        panelRound2Layout.setVerticalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRegistros1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(txtNRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpiarFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout vPLoginBackground1Layout = new javax.swing.GroupLayout(vPLoginBackground1);
        vPLoginBackground1.setLayout(vPLoginBackground1Layout);
        vPLoginBackground1Layout.setHorizontalGroup(
            vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                        .addContainerGap(106, Short.MAX_VALUE)
                        .addComponent(vPLogo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 93, Short.MAX_VALUE))
                    .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelRound2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panelRound1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, vPLoginBackground1Layout.createSequentialGroup()
                                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        vPLoginBackground1Layout.setVerticalGroup(
            vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vPLoginBackground1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(vPLogo2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(vPLoginBackground1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRound1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRound2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(vPLoginBackground1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(vPLoginBackground1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVolverMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            new VInicio().setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverMousePressed

    private void btnGuardarFormularioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarFormularioMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            // Validar la información
            if (!cCliente.validarInformacion(formulario)) {
                return;
            }
            if (tblClientes.getSelectedRow() == -1) {
                // Se quiere añadir
                // Tipo y número de documento
                String documentoTipo = formulario.comboBoxTipoDocumento.getSelectedItem().toString();
                String nuDocumento = formulario.txtNDocumento.getText();
                if (cCliente.existePersona(documentoTipo, nuDocumento)) {
                    JOptionPane.showMessageDialog(null, "Ya existe un registro con ese tipo y número de documento");
                    return;
                }
                // persona
                MPersona mCliente = new MPersona();
                mCliente.setNombres(formulario.txtNombres.getText());
                mCliente.setApellidos(formulario.txtApellidos.getText());
                mCliente.setDocumento_tipo(formulario.comboBoxTipoDocumento.getSelectedItem().toString());
                mCliente.setNu_documento(formulario.txtNDocumento.getText());
                mCliente.setDireccion(formulario.txtDireccion.getText());
                mCliente.setTelefono(formulario.txtTelefono.getText());
                mCliente.setCelular(formulario.txtCelular.getText());
                mCliente.setEmail(formulario.txtEmail.getText());
                
                if (cCliente.insertar(mCliente, formulario)) {
                    clearData();
                    buscar(txtBuscar.getText());
                    JOptionPane.showMessageDialog(null, "Añadido exitosamente", "Alerta", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Hubo un problema añadiendo", "Alerta", JOptionPane.ERROR_MESSAGE);
                }
                
            } else {
                // Se quiere modificar
                // Tipo y número de documento
                String documentoTipo = formulario.comboBoxTipoDocumento.getSelectedItem().toString();
                String nuDocumento = formulario.txtNDocumento.getText();
                if (cCliente.existePersona(documentoTipo, nuDocumento)) {
                    if (!mClienteSeleccionado.getNu_documento().equals(formulario.txtNDocumento.getText())
                            ||
                        !mClienteSeleccionado.getDocumento_tipo().equals(formulario.comboBoxTipoDocumento.getSelectedItem().toString())) 
                    {
                        JOptionPane.showMessageDialog(null, "Ya existe un registro con ese tipo y número de documento");
                        return;
                    }
                }
                mClienteSeleccionado.setNombres(formulario.txtNombres.getText());
                mClienteSeleccionado.setApellidos(formulario.txtApellidos.getText());
                mClienteSeleccionado.setDocumento_tipo(formulario.comboBoxTipoDocumento.getSelectedItem().toString());
                mClienteSeleccionado.setNu_documento(formulario.txtNDocumento.getText());
                mClienteSeleccionado.setDireccion(formulario.txtDireccion.getText());
                mClienteSeleccionado.setTelefono(formulario.txtTelefono.getText());
                mClienteSeleccionado.setCelular(formulario.txtCelular.getText());
                mClienteSeleccionado.setEmail(formulario.txtEmail.getText());
                if (cCliente.editar(mClienteSeleccionado, formulario)) {
                    clearData();
                    buscar(txtBuscar.getText());
                    JOptionPane.showMessageDialog(null, "Modificado exitosamente", "Alerta", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Hubo un problema modificando", "Alerta", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btnGuardarFormularioMousePressed

    private void btnLimpiarFormularioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarFormularioMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            txtNRegistro.setText("Seleccione un registro");
            clearData();
        }
    }//GEN-LAST:event_btnLimpiarFormularioMousePressed

    private void btnBorrarTablaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBorrarTablaMousePressed
        if (SwingUtilities.isLeftMouseButton(evt)) {
            borrarCliente();
        }
    }//GEN-LAST:event_btnBorrarTablaMousePressed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER || txtBuscar.getText().isEmpty()) {
            clearData();
            buscar(txtBuscar.getText());
        }
    }//GEN-LAST:event_txtBuscarKeyReleased
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Vista.Componentes.LabelRound btnBorrarTabla;
    private Vista.Componentes.LabelRound btnGuardarFormulario;
    private Vista.Componentes.LabelRound btnLimpiarFormulario;
    private Vista.Componentes.LabelRound btnVolver;
    private Vista.Panel.VPClientes formulario;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblRegistros;
    private javax.swing.JLabel lblRegistros1;
    private Vista.Componentes.PanelRound panelRound1;
    private Vista.Componentes.PanelRound panelRound2;
    private javax.swing.JTable tblClientes;
    private Vista.Componentes.CustomTextField txtBuscar;
    private Vista.Componentes.CustomTextField txtNRegistro;
    private Vista.Componentes.PanelRound vPLoginBackground1;
    private Vista.Panel.VPLogo vPLogo2;
    // End of variables declaration//GEN-END:variables
}
